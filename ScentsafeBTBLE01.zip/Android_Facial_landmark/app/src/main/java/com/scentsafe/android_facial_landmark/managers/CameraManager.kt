package com.scentsafe.android_facial_landmark.managers

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.TextureView
import androidx.core.content.PermissionChecker

class CameraManager(private val context: Context) {

    private lateinit var cameraManager: android.hardware.camera2.CameraManager
    private lateinit var cameraDevice: CameraDevice
    private lateinit var captureSession: CameraCaptureSession
    private lateinit var backgroundThread: HandlerThread
    private lateinit var backgroundHandler: Handler

    private var frontCameraId: String? = null
    private var previewSize: Size? = null

    fun initialize() {
        cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        findFrontCamera()
        startBackgroundThread()
    }

    private fun findFrontCamera() {
        try {
            for (cameraId in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    frontCameraId = cameraId
                    val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
                    previewSize = sizes?.find { it.width == 1280 && it.height == 720 }
                        ?: sizes?.find { it.width == 640 && it.height == 480 }
                                ?: sizes?.firstOrNull()
                    break
                }
            }
        } catch (e: CameraAccessException) {
            Log.e("Camera", "查找前置摄像头失败: ${e.message}")
        }
    }

    fun openCamera(textureView: TextureView, callback: (Boolean) -> Unit) {
        frontCameraId?.let { cameraId ->
            try {
                if (PermissionChecker.checkSelfPermission(context, android.Manifest.permission.CAMERA)
                    != PermissionChecker.PERMISSION_GRANTED) {
                    callback(false)
                    return
                }

                cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) {
                        cameraDevice = camera
                        createCameraPreviewSession(textureView) { success ->
                            callback(success)
                        }
                    }

                    override fun onDisconnected(camera: CameraDevice) {
                        camera.close()
                        callback(false)
                    }

                    override fun onError(camera: CameraDevice, error: Int) {
                        camera.close()
                        Log.e("Camera", "相机启动失败，错误码: $error")
                        callback(false)
                    }
                }, backgroundHandler)
            } catch (e: CameraAccessException) {
                Log.e("Camera", "打开相机失败: ${e.message}")
                callback(false)
            }
        } ?: run {
            Log.e("Camera", "未找到前置摄像头")
            callback(false)
        }
    }

    private fun createCameraPreviewSession(textureView: TextureView, callback: (Boolean) -> Unit) {
        try {
            val texture = textureView.surfaceTexture
            previewSize?.let { size ->
                texture?.setDefaultBufferSize(size.width, size.height)
            }

            val surface = Surface(texture)
            val previewRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewRequestBuilder.addTarget(surface)

            cameraDevice.createCaptureSession(
                listOf(surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        updatePreview(previewRequestBuilder)
                        callback(true)
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e("Camera", "相机配置失败")
                        callback(false)
                    }
                },
                null
            )
        } catch (e: CameraAccessException) {
            Log.e("Camera", "创建预览会话失败: ${e.message}")
            callback(false)
        }
    }

    private fun updatePreview(previewRequestBuilder: CaptureRequest.Builder) {
        try {
            previewRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            previewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            captureSession.setRepeatingRequest(previewRequestBuilder.build(), null, backgroundHandler)
        } catch (e: CameraAccessException) {
            Log.e("Camera", "更新预览失败: ${e.message}")
        }
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread.looper)
    }

    fun stopBackgroundThread() {
        if (::backgroundThread.isInitialized) {
            backgroundThread.quitSafely()
            try {
                backgroundThread.join()
            } catch (e: InterruptedException) {
                Log.e("Camera", "停止后台线程失败: ${e.message}")
            }
        }
    }

    fun closeCamera() {
        if (::captureSession.isInitialized) {
            captureSession.close()
        }
        if (::cameraDevice.isInitialized) {
            cameraDevice.close()
        }
    }
}
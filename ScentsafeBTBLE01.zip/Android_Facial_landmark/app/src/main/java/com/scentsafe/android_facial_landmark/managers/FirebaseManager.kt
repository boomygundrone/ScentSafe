package com.scentsafe.android_facial_landmark.managers

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.scentsafe.android_facial_landmark.data.DrowsinessData
import com.scentsafe.android_facial_landmark.data.HeartRateData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FirebaseManager(private val context: Context, private val scope: CoroutineScope) {

    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var drowsinessRef: DatabaseReference
    private lateinit var heartRateRef: DatabaseReference
    private var firebaseConnected = false
    private var lastFirebaseUpdate = 0L
    private var firebaseInitialized = false

    fun initialize() {
        try {
            if (!firebaseInitialized) {
                firebaseDatabase = FirebaseDatabase.getInstance(
                    "https://scentsafe-17cfd-default-rtdb.asia-southeast1.firebasedatabase.app/"
                )

                try {
                    firebaseDatabase.setPersistenceEnabled(true)
                    Log.d("Firebase", "持久化已启用")
                } catch (e: Exception) {
                    Log.w("Firebase", "持久化启用失败或已启用: ${e.message}")
                }

                drowsinessRef = firebaseDatabase.getReference("drowsiness_status")
                heartRateRef = firebaseDatabase.getReference("heart_rate")

                drowsinessRef.keepSynced(true)
                heartRateRef.keepSynced(true)

                firebaseInitialized = true
            }

            setupConnectionListener()
            Log.d("Firebase", "Firebase初始化成功")

        } catch (e: Exception) {
            Log.e("Firebase", "Firebase初始化失败: ${e.message}")
            Toast.makeText(context, "Firebase初始化失败: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupConnectionListener() {
        val connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected")
        connectedRef.addValueEventListener(object : com.google.firebase.database.ValueEventListener {
            override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                val wasConnected = firebaseConnected
                firebaseConnected = snapshot.getValue(Boolean::class.java) ?: false
                Log.d("Firebase", "连接状态: $firebaseConnected")

                if (wasConnected != firebaseConnected) {
                    if (firebaseConnected) {
                        Toast.makeText(context, "Firebase已连接", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Firebase连接断开", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                Log.e("Firebase", "连接状态监听失败: ${error.message}")
            }
        })
    }

    fun updateDrowsinessData(data: DrowsinessData) {
        scope.launch(Dispatchers.IO) {
            try {
                val firebaseData = mapOf(
                    "blinkCount" to data.blinkCount,
                    "eyeAspectRatio" to data.eyeAspectRatio,
                    "mouthAspectRatio" to data.mouthAspectRatio,
                    "state" to data.state,
                    "timestamp" to data.timestamp,
                    "yawnCount" to data.yawnCount,
                    "lastUpdate" to ServerValue.TIMESTAMP,
                    "frameCount" to data.frameCount,
                    "appVersion" to data.appVersion,
                    "heartRate" to data.heartRate,
                    "heartRateMonitoring" to data.heartRateMonitoring
                )

                drowsinessRef.setValue(firebaseData)
                    .addOnSuccessListener {
                        lastFirebaseUpdate = System.currentTimeMillis()
                        Log.d("Firebase", "成功更新Firebase")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "Firebase更新失败: ${exception.message}")
                        retryUpdate(firebaseData, 1, 3)
                    }

            } catch (e: Exception) {
                Log.e("Firebase", "Firebase操作异常: ${e.message}")
            }
        }
    }

    fun updateHeartRateData(heartRateData: HeartRateData) {
        scope.launch(Dispatchers.IO) {
            try {
                val data = mapOf(
                    "heartRate" to heartRateData.heartRate,
                    "timestamp" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault())
                        .format(Date(heartRateData.timestamp)),
                    "quality" to heartRateData.quality,
                    "lastUpdate" to ServerValue.TIMESTAMP
                )

                heartRateRef.setValue(data)
                    .addOnSuccessListener {
                        Log.d("Firebase", "心率数据上传成功: ${heartRateData.heartRate} BPM")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "心率数据上传失败: ${exception.message}")
                    }

            } catch (e: Exception) {
                Log.e("Firebase", "心率数据上传异常: ${e.message}")
            }
        }
    }

    private fun retryUpdate(data: Map<String, Any?>, currentRetry: Int, maxRetries: Int) {
        if (currentRetry > maxRetries) {
            Log.e("Firebase", "Firebase更新最终失败，已重试 $maxRetries 次")
            Toast.makeText(context, "Firebase连接失败，正在重连...", Toast.LENGTH_SHORT).show()
            reconnect()
            return
        }

        Handler(Looper.getMainLooper()).postDelayed({
            scope.launch(Dispatchers.IO) {
                try {
                    drowsinessRef.setValue(data)
                        .addOnSuccessListener {
                            lastFirebaseUpdate = System.currentTimeMillis()
                            Log.d("Firebase", "重试成功更新Firebase (第 $currentRetry 次重试)")
                        }
                        .addOnFailureListener { exception ->
                            Log.e("Firebase", "第 $currentRetry 次重试失败: ${exception.message}")
                            retryUpdate(data, currentRetry + 1, maxRetries)
                        }
                } catch (e: Exception) {
                    Log.e("Firebase", "重试时发生异常: ${e.message}")
                    retryUpdate(data, currentRetry + 1, maxRetries)
                }
            }
        }, (1000 * currentRetry).toLong())
    }

    fun reconnect() {
        scope.launch(Dispatchers.IO) {
            try {
                Log.d("Firebase", "重新初始化Firebase连接...")
                Toast.makeText(context, "正在重新连接Firebase...", Toast.LENGTH_SHORT).show()

                firebaseDatabase.goOffline()
                kotlinx.coroutines.delay(3000)
                firebaseDatabase.goOnline()

                Log.d("Firebase", "Firebase重连完成")

            } catch (e: Exception) {
                Log.e("Firebase", "Firebase重连失败: ${e.message}")
                Toast.makeText(context, "Firebase重连失败", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun sendHeartbeat() {
        scope.launch(Dispatchers.IO) {
            try {
                if (::firebaseDatabase.isInitialized) {
                    val heartbeatRef = firebaseDatabase.getReference("heartbeat")
                    heartbeatRef.setValue(ServerValue.TIMESTAMP)
                        .addOnSuccessListener {
                            Log.d("Firebase", "心跳包发送成功")
                        }
                        .addOnFailureListener { exception ->
                            Log.e("Firebase", "心跳包发送失败: ${exception.message}")
                        }
                }
            } catch (e: Exception) {
                Log.e("Firebase", "心跳包异常: ${e.message}")
            }
        }
    }

    fun goOnline() {
        if (::firebaseDatabase.isInitialized) {
            firebaseDatabase.goOnline()
            Log.d("Firebase", "Firebase重新上线")
        }
    }

    fun isConnected(): Boolean = firebaseConnected
    fun getLastUpdateTime(): Long = lastFirebaseUpdate
}
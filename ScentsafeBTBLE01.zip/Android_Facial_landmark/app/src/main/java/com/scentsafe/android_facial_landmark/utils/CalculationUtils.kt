package com.scentsafe.android_facial_landmark.utils

import com.scentsafe.android_facial_landmark.data.Point2D
import kotlin.math.pow
import kotlin.math.sqrt

object CalculationUtils {

    fun calculateEAR(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Double {
        return try {
            val leftEyePoints = listOf(
                Point2D(landmarks[33].x(), landmarks[33].y()),
                Point2D(landmarks[160].x(), landmarks[160].y()),
                Point2D(landmarks[158].x(), landmarks[158].y()),
                Point2D(landmarks[133].x(), landmarks[133].y()),
                Point2D(landmarks[153].x(), landmarks[153].y()),
                Point2D(landmarks[144].x(), landmarks[144].y())
            )

            val rightEyePoints = listOf(
                Point2D(landmarks[362].x(), landmarks[362].y()),
                Point2D(landmarks[385].x(), landmarks[385].y()),
                Point2D(landmarks[387].x(), landmarks[387].y()),
                Point2D(landmarks[263].x(), landmarks[263].y()),
                Point2D(landmarks[373].x(), landmarks[373].y()),
                Point2D(landmarks[380].x(), landmarks[380].y())
            )

            val leftEAR = calculateEnhancedEAR(leftEyePoints)
            val rightEAR = calculateEnhancedEAR(rightEyePoints)

            (leftEAR + rightEAR) / 2.0
        } catch (e: Exception) {
            android.util.Log.e("EAR", "EAR计算错误: ${e.message}")
            0.3
        }
    }

    fun calculateMAR(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Double {
        return try {
            val upperLip = Point2D(landmarks[13].x(), landmarks[13].y())
            val lowerLip = Point2D(landmarks[14].x(), landmarks[14].y())
            val leftCorner = Point2D(landmarks[61].x(), landmarks[61].y())
            val rightCorner = Point2D(landmarks[291].x(), landmarks[291].y())

            val upperLip2 = Point2D(landmarks[12].x(), landmarks[12].y())
            val lowerLip2 = Point2D(landmarks[15].x(), landmarks[15].y())

            val vertical1 = distance(upperLip, lowerLip)
            val vertical2 = distance(upperLip2, lowerLip2)
            val avgVertical = (vertical1 + vertical2) / 2.0

            val horizontal = distance(leftCorner, rightCorner)

            if (horizontal > 0) avgVertical / horizontal else 0.0
        } catch (e: Exception) {
            android.util.Log.e("MAR", "MAR计算错误: ${e.message}")
            0.3
        }
    }

    private fun calculateEnhancedEAR(eyePoints: List<Point2D>): Double {
        val vertical1 = distance(eyePoints[1], eyePoints[5])
        val vertical2 = distance(eyePoints[2], eyePoints[4])
        val horizontal = distance(eyePoints[0], eyePoints[3])

        return if (horizontal > 0) {
            (vertical1 + vertical2) / (2.0 * horizontal)
        } else 0.0
    }

    private fun distance(p1: Point2D, p2: Point2D): Double {
        return sqrt((p1.x - p2.x).toDouble().pow(2) + (p1.y - p2.y).toDouble().pow(2))
    }

    fun isMouthLandmark(index: Int): Boolean {
        val mouthIndices = setOf(
            0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175,
            61, 84, 17, 314, 405, 320, 307, 375, 321, 308, 324, 318, 402, 317,
            14, 87, 178, 88, 95, 78, 191, 80, 81, 82, 13, 312, 311, 310, 415,
            61, 291, 39, 181, 0, 269
        )
        return mouthIndices.contains(index)
    }

    fun isEyeLandmark(index: Int): Boolean {
        val eyeIndices = setOf(
            33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246,
            362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398
        )
        return eyeIndices.contains(index)
    }
}
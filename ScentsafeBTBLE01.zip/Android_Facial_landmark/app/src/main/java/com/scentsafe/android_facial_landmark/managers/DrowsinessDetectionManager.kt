package com.scentsafe.android_facial_landmark.managers

import android.util.Log
import com.scentsafe.android_facial_landmark.data.DetectionConstants
import com.scentsafe.android_facial_landmark.utils.CalculationUtils

class DrowsinessDetectionManager {

    // 状态变量
    var currentState = "NORMAL"
        private set
    private var eyesClosedStartTime: Long? = null
    private var yawnStartTime: Long? = null
    var yawnCount = 0
        private set
    var blinkCount = 0
        private set
    var rapidBlinkCount = 0
        private set
    private var resetTime = System.currentTimeMillis()
    private var blinkResetTime = System.currentTimeMillis()
    private var rapidBlinkResetTime = System.currentTimeMillis()

    // 状态标记
    var wasEyesClosed = false
        private set
    var wasYawning = false
        private set
    private var lastBlinkTime = 0L

    // 滑动窗口数据
    private val earHistory = mutableListOf<Double>()
    private val marHistory = mutableListOf<Double>()

    // 检测敏感度设置
    private var baselineEAR = 0.0
    private var baselineMAR = 0.0
    var isBaselineSet = false
        private set
    var frameCount = 0
        private set

    // 当前检测值
    var currentEAR = 0.0
        private set
    var currentMAR = 0.0
        private set
    var currentEARThresh = DetectionConstants.EAR_THRESH
        private set
    var currentMARThresh = DetectionConstants.MAR_THRESH
        private set

    fun processDetection(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>) {
        frameCount++

        val ear = CalculationUtils.calculateEAR(landmarks)
        val mar = CalculationUtils.calculateMAR(landmarks)

        currentEAR = ear
        currentMAR = mar

        establishBaseline(ear, mar)
        addToHistory(ear, mar)
        val smoothEAR = getSmoothedEAR()
        val smoothMAR = getSmoothedMAR()

        val currentTime = System.currentTimeMillis()

        currentEARThresh = if (isBaselineSet) baselineEAR * 0.70 else DetectionConstants.EAR_THRESH
        currentMARThresh = if (isBaselineSet) baselineMAR * 1.4 else DetectionConstants.MAR_THRESH

        detectYawn(smoothMAR, currentMARThresh, currentTime)
        detectBlink(smoothEAR, currentEARThresh, currentTime)

        resetCounters(currentTime)
        updateDrowsinessState(currentTime)
    }

    fun resetDetectionState() {
        wasEyesClosed = false
        wasYawning = false
        eyesClosedStartTime = null
        yawnStartTime = null
    }

    private fun establishBaseline(ear: Double, mar: Double) {
        if (!isBaselineSet && frameCount <= DetectionConstants.BASELINE_FRAMES) {
            baselineEAR = (baselineEAR * (frameCount - 1) + ear) / frameCount
            baselineMAR = (baselineMAR * (frameCount - 1) + mar) / frameCount

            if (frameCount == DetectionConstants.BASELINE_FRAMES) {
                isBaselineSet = true
                Log.d("Baseline", "基线建立完成 - EAR: $baselineEAR, MAR: $baselineMAR")
            }
        }
    }

    private fun detectYawn(mar: Double, threshold: Double, currentTime: Long) {
        if (mar >= threshold) {
            if (!wasYawning) {
                yawnStartTime = currentTime
                wasYawning = true
                Log.d("Yawn", "开始打哈欠: MAR = $mar")
            }
        } else {
            if (wasYawning && yawnStartTime != null) {
                val yawnDuration = currentTime - yawnStartTime!!
                if (yawnDuration >= DetectionConstants.YAWN_DURATION) {
                    yawnCount++
                    Log.d("Yawn", "检测到打哈欠! 持续: ${yawnDuration}ms, 计数: $yawnCount")
                }
                wasYawning = false
                yawnStartTime = null
            }
        }
    }

    private fun detectBlink(ear: Double, threshold: Double, currentTime: Long) {
        if (ear < threshold) {
            if (!wasEyesClosed) {
                wasEyesClosed = true
                eyesClosedStartTime = currentTime
            }
        } else {
            if (wasEyesClosed) {
                blinkCount++

                if (currentTime - lastBlinkTime < 400) {
                    rapidBlinkCount++
                    Log.d("RapidBlink", "快速眨眼检测: $rapidBlinkCount")
                }

                lastBlinkTime = currentTime
                wasEyesClosed = false
                eyesClosedStartTime = null

                Log.d("Blink", "眨眼检测: 总计 $blinkCount, 快速 $rapidBlinkCount")
            }
        }

        eyesClosedStartTime?.let { startTime ->
            if (currentTime - startTime >= DetectionConstants.EYES_CLOSED_DURATION) {
                Log.d("LongBlink", "长时间闭眼: ${currentTime - startTime}ms")
                currentState = "DROWSINESS"
            }
        }
    }

    private fun addToHistory(ear: Double, mar: Double) {
        earHistory.add(ear)
        marHistory.add(mar)

        if (earHistory.size > DetectionConstants.HISTORY_SIZE) {
            earHistory.removeAt(0)
        }
        if (marHistory.size > DetectionConstants.HISTORY_SIZE) {
            marHistory.removeAt(0)
        }
    }

    fun getSmoothedEAR(): Double {
        return if (earHistory.isNotEmpty()) {
            earHistory.average()
        } else 0.3
    }

    fun getSmoothedMAR(): Double {
        return if (marHistory.isNotEmpty()) {
            marHistory.average()
        } else 0.3
    }

    private fun resetCounters(currentTime: Long) {
        if (currentTime - resetTime > DetectionConstants.TIME_WINDOW) {
            yawnCount = 0
            blinkCount = 0
            resetTime = currentTime
            Log.d("Reset", "重置主计数器")
        }

        if (currentTime - blinkResetTime > DetectionConstants.BLINK_TIME_WINDOW) {
            blinkResetTime = currentTime
        }

        if (currentTime - rapidBlinkResetTime > DetectionConstants.RAPID_BLINK_WINDOW) {
            rapidBlinkCount = 0
            rapidBlinkResetTime = currentTime
        }
    }

    private fun updateDrowsinessState(currentTime: Long) {
        currentState = when {
            yawnCount >= DetectionConstants.DROWSINESS_YAWN_THRESH ||
                    blinkCount >= DetectionConstants.DROWSINESS_BLINK_THRESH ||
                    rapidBlinkCount >= (DetectionConstants.RAPID_BLINK_THRESH * 2) ||
                    wasYawning && (currentTime - (yawnStartTime ?: 0)) > 2000 -> {
                "DROWSINESS"
            }

            yawnCount >= DetectionConstants.YAWN_THRESH ||
                    blinkCount >= DetectionConstants.BLINK_THRESH ||
                    rapidBlinkCount >= DetectionConstants.RAPID_BLINK_THRESH ||
                    wasYawning -> {
                "WARNING"
            }

            else -> "NORMAL"
        }
    }

    fun getBaselineEAR(): Double = baselineEAR
    fun getBaselineMAR(): Double = baselineMAR
}
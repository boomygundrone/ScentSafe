package com.scentsafe.android_facial_landmark

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HeartRateActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var heartRateTextView: TextView
    private lateinit var statusTextView: TextView
    private lateinit var measureButton: Button
    private lateinit var stopButton: Button
    private lateinit var backButton: Button

    private var sensorManager: SensorManager? = null
    private var heartRateSensor: Sensor? = null
    private var currentHeartRate = 75 // 默认值
    private var isMonitoring = false
    private var lastHeartRateUpdate = 0L

    // Firebase
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var heartRateRef: DatabaseReference

    // 模拟心率
    private var heartRateHandler: Handler? = null
    private var heartRateRunnable: Runnable? = null

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_heart_rate)

        initViews()
        initFirebase()
        initSensors()
        setupButtonListeners()

        // 初始状态显示默认心率
        updateHeartRateDisplay(75)
        updateFirebaseHeartRate(75, false)
    }

    private fun initViews() {
        heartRateTextView = findViewById(R.id.heartRateTextView)
        statusTextView = findViewById(R.id.statusTextView)
        measureButton = findViewById(R.id.measureButton)
        stopButton = findViewById(R.id.stopButton)
        backButton = findViewById(R.id.backButton)

        statusTextView.text = "Heart rate monitoring is off"
        stopButton.isEnabled = false
    }

    private fun initFirebase() {
        try {
            firebaseDatabase = FirebaseDatabase.getInstance("https://scentsafe-17cfd-default-rtdb.asia-southeast1.firebasedatabase.app/")
            heartRateRef = firebaseDatabase.getReference("heartRate_value")
            Log.d("HeartRate", "Firebase Initialization successful")
        } catch (e: Exception) {
            Log.e("HeartRate", "Firebase Initialization failure: ${e.message}")
        }
    }

    private fun initSensors() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        heartRateSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_HEART_RATE)

        if (heartRateSensor != null) {
            Log.d("HeartRate", "Find the heart rate sensor")
        } else {
            Log.w("HeartRate", "The device does not support a heart rate sensor, simulated data will be used")
        }
    }

    private fun setupButtonListeners() {
        measureButton.setOnClickListener {
            startHeartRateMonitoring()
        }

        stopButton.setOnClickListener {
            stopHeartRateMonitoring()
        }

        backButton.setOnClickListener {
            finish()
        }
    }

    private fun startHeartRateMonitoring() {
        if (isMonitoring) return

        isMonitoring = true
        measureButton.isEnabled = false
        stopButton.isEnabled = true
        statusTextView.text = "Measuring heart rate..."

        if (heartRateSensor != null) {
            // 使用真实传感器
            sensorManager?.registerListener(this, heartRateSensor, SensorManager.SENSOR_DELAY_NORMAL)
            Log.d("HeartRate", "Start measuring heart rate using the sensor")

            // 设置超时，如果10秒内没有数据就使用模拟数据
            Handler(Looper.getMainLooper()).postDelayed({
                if (isMonitoring && currentHeartRate == 75) {
                    Log.w("HeartRate", "No data from sensor, switch to simulation mode")
                    startSimulatedHeartRate()
                }
            }, 10000)
        } else {
            // 使用模拟数据
            startSimulatedHeartRate()
        }

        Toast.makeText(this, "Start heart rate measurement", Toast.LENGTH_SHORT).show()
    }

    private fun stopHeartRateMonitoring() {
        isMonitoring = false
        measureButton.isEnabled = true
        stopButton.isEnabled = false
        statusTextView.text = "Heart rate monitoring off"

        // 停止传感器
        sensorManager?.unregisterListener(this)

        // 停止模拟心率
        heartRateHandler?.removeCallbacks(heartRateRunnable ?: return)

        // 设置为默认值
        currentHeartRate = 75
        updateHeartRateDisplay(75)
        updateFirebaseHeartRate(75, false)

        Toast.makeText(this, "Heart rate measurement stopped", Toast.LENGTH_SHORT).show()
        Log.d("HeartRate", "Heart rate monitoring stopped")
    }

    private fun startSimulatedHeartRate() {
        heartRateHandler = Handler(Looper.getMainLooper())
        heartRateRunnable = object : Runnable {
            override fun run() {
                if (!isMonitoring) return

                // 模拟真实心率变化
                val simulatedHeartRate = (65..95).random()
                currentHeartRate = simulatedHeartRate
                lastHeartRateUpdate = System.currentTimeMillis()

                updateHeartRateDisplay(simulatedHeartRate)
                updateFirebaseHeartRate(simulatedHeartRate, true)

                Log.d("HeartRate", "Simulated heart rate: $simulatedHeartRate BPM")

                // 每3秒更新一次（更频繁的更新）
                heartRateHandler?.postDelayed(this, 3000)
            }
        }
        heartRateHandler?.post(heartRateRunnable!!)
    }

    private fun updateHeartRateDisplay(bpm: Int) {
        runOnUiThread {
            heartRateTextView.text = "$bpm BPM"
            heartRateTextView.setTextColor(
                when {
                    !isMonitoring -> ContextCompat.getColor(this, android.R.color.darker_gray)
                    bpm < 60 -> ContextCompat.getColor(this, android.R.color.holo_blue_bright)
                    bpm in 60..100 -> ContextCompat.getColor(this, android.R.color.holo_green_light)
                    else -> ContextCompat.getColor(this, android.R.color.holo_red_light)
                }
            )

            if (isMonitoring) {
                statusTextView.text = when {
                    bpm < 60 -> "Low heart rate"
                    bpm in 60..100 -> "Normal heart rate"
                    else -> "High heart rate"
                }
            }
        }
    }

    private fun updateFirebaseHeartRate(bpm: Int, monitoring: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                val heartRateData = mapOf(
                    "bpm" to bpm,
                    "timestamp" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date()),
                    "lastUpdate" to ServerValue.TIMESTAMP,
                    "isMonitoring" to monitoring,
                    "deviceSupportsHeartRate" to (heartRateSensor != null),
                    "source" to if (heartRateSensor != null && monitoring) "sensor" else "default"
                )

                heartRateRef.setValue(heartRateData)
                    .addOnSuccessListener {
                        Log.d("Firebase", "Heart rate data updated successfully: $bpm BPM")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "Heart rate data update failed: ${exception.message}")
                    }
            } catch (e: Exception) {
                Log.e("Firebase", "Heart rate data update abnormality: ${e.message}")
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_HEART_RATE && isMonitoring) {
            val heartRate = event.values[0].toInt()
            if (heartRate > 0) {
                currentHeartRate = heartRate
                lastHeartRateUpdate = System.currentTimeMillis()
                updateHeartRateDisplay(heartRate)
                updateFirebaseHeartRate(heartRate, true)
                Log.d("HeartRate", "Sensor heart rate: $heartRate BPM")
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        Log.d("HeartRate", "Sensor accuracy changes: $accuracy")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopHeartRateMonitoring()
        scope.cancel()
    }

    override fun onPause() {
        super.onPause()
        if (isMonitoring) {
            sensorManager?.unregisterListener(this)
        }
    }

    override fun onResume() {
        super.onResume()
        if (isMonitoring && heartRateSensor != null) {
            sensorManager?.registerListener(this, heartRateSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }
}
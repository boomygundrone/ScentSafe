package com.scentsafe.android_facial_landmark.managers

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

class BluetoothManager(private val context: Context, private val scope: CoroutineScope) {

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var bluetoothOutputStream: OutputStream? = null

    init {
        initialize()
    }

    private fun initialize() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            Log.w("Bluetooth", "设备不支持蓝牙")
        }
    }

    fun connectToDevice(deviceAddress: String) {
        scope.launch(Dispatchers.IO) {
            try {
                if (ActivityCompat.checkSelfPermission(
                        context,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    return@launch
                }

                val device: BluetoothDevice = bluetoothAdapter!!.getRemoteDevice(deviceAddress)
                bluetoothSocket = device.createRfcommSocketToServiceRecord(
                    UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
                )
                bluetoothSocket?.connect()
                bluetoothOutputStream = bluetoothSocket?.outputStream
                Log.d("Bluetooth", "蓝牙连接成功")
            } catch (e: IOException) {
                Log.e("Bluetooth", "蓝牙连接失败: ${e.message}")
            }
        }
    }

    fun sendData(data: String) {
        scope.launch(Dispatchers.IO) {
            try {
                bluetoothOutputStream?.write("$data\n".toByteArray())
                bluetoothOutputStream?.flush()
                Log.d("Bluetooth", "发送到蓝牙设备: $data")
            } catch (e: IOException) {
                Log.e("Bluetooth", "蓝牙发送失败: ${e.message}")
            }
        }
    }

    fun sendStateWithHeartRate(state: String, heartRate: Int) {
        val message = if (heartRate > 0) "$state|HR:$heartRate" else state
        sendData(message)
    }

    fun disconnect() {
        try {
            bluetoothSocket?.close()
            Log.d("Bluetooth", "蓝牙连接已关闭")
        } catch (e: IOException) {
            Log.e("Bluetooth", "关闭蓝牙连接失败: ${e.message}")
        }
    }

    fun isConnected(): Boolean {
        return bluetoothSocket?.isConnected ?: false
    }
}
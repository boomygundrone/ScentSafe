package com.scentsafe.android_facial_landmark.data

data class Point2D(val x: Float, val y: Float)

data class HeartRateData(
    val heartRate: Int,
    val timestamp: Long,
    val quality: String = "GOOD"
)

data class DrowsinessData(
    val blinkCount: Int,
    val eyeAspectRatio: Double,
    val mouthAspectRatio: Double,
    val state: String,
    val timestamp: String,
    val yawnCount: Int,
    val frameCount: Int,
    val appVersion: String,
    val heartRate: Int? = null,
    val heartRateMonitoring: Boolean = false
)

object DetectionConstants {
    // 检测参数
    const val EAR_THRESH = 0.18
    const val MAR_THRESH = 0.65
    const val EYES_CLOSED_DURATION = 1500L
    const val YAWN_DURATION = 1000L

    // 计数阈值
    const val YAWN_THRESH = 3
    const val BLINK_THRESH = 15
    const val RAPID_BLINK_THRESH = 8
    const val DROWSINESS_YAWN_THRESH = 5
    const val DROWSINESS_BLINK_THRESH = 25

    // 时间窗口
    const val TIME_WINDOW = 60000L
    const val BLINK_TIME_WINDOW = 10000L
    const val RAPID_BLINK_WINDOW = 5000L

    // 基线参数
    const val BASELINE_FRAMES = 50
    const val HISTORY_SIZE = 5

    // 更新间隔
    const val FIREBASE_UPDATE_INTERVAL = 2000L
    const val FIREBASE_TIMEOUT_CHECK = 15000L
    const val INFERENCE_INTERVAL_MS = 50L
    const val UI_UPDATE_INTERVAL = 200L
    const val HEART_RATE_UPDATE_INTERVAL = 5000L

    // 权限代码
    const val CAMERA_PERMISSION_CODE = 100
    const val HEALTH_PERMISSION_CODE = 101
}
package com.scentsafe.android_facial_landmark

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SoundSettingsActivity : AppCompatActivity() {

    private lateinit var soundEnabledSwitch: Switch
    private lateinit var warningRadioGroup: RadioGroup
    private lateinit var drowsinessRadioGroup: RadioGroup
    private lateinit var testWarningButton: Button
    private lateinit var testDrowsinessButton: Button
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button

    private lateinit var sharedPreferences: SharedPreferences
    private var testMediaPlayer: MediaPlayer? = null

    private var soundEnabled = true
    private var selectedWarningSound = "bell"
    private var selectedDrowsinessSound = "alarm"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sound_settings)

        initializeViews()
        loadCurrentSettings()
        setupEventListeners()
    }

    private fun initializeViews() {
        soundEnabledSwitch = findViewById(R.id.soundEnabledSwitch)
        warningRadioGroup = findViewById(R.id.warningRadioGroup)
        drowsinessRadioGroup = findViewById(R.id.drowsinessRadioGroup)
        testWarningButton = findViewById(R.id.testWarningButton)
        testDrowsinessButton = findViewById(R.id.testDrowsinessButton)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)

        sharedPreferences = getSharedPreferences("DrowsinessDetectionSettings", Context.MODE_PRIVATE)
    }

    private fun loadCurrentSettings() {
        soundEnabled = sharedPreferences.getBoolean("sound_enabled", true)
        selectedWarningSound = sharedPreferences.getString("warning_sound", "bell") ?: "bell"
        selectedDrowsinessSound = sharedPreferences.getString("drowsiness_sound", "alarm") ?: "alarm"

        soundEnabledSwitch.isChecked = soundEnabled

        // Set warning sound selection - 修复ID匹配问题
        when (selectedWarningSound) {
            "bell" -> findViewById<RadioButton>(R.id.warningBellRadio).isChecked = true
            "cash" -> findViewById<RadioButton>(R.id.warningCashRadio).isChecked = true
            "cock" -> findViewById<RadioButton>(R.id.warningCockRadio).isChecked = true
        }

        // Set drowsiness sound selection - 修复ID匹配问题
        when (selectedDrowsinessSound) {
            "alarm" -> findViewById<RadioButton>(R.id.drowsinessAlarmRadio).isChecked = true
            "yay" -> findViewById<RadioButton>(R.id.drowsinessYayRadio).isChecked = true
            "urgent" -> findViewById<RadioButton>(R.id.drowsinessUrgentRadio).isChecked = true
        }

        updateUIState()
    }

    private fun setupEventListeners() {
        soundEnabledSwitch.setOnCheckedChangeListener { _, isChecked ->
            soundEnabled = isChecked
            updateUIState()
        }

        // 修复ID匹配问题
        warningRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedWarningSound = when (checkedId) {
                R.id.warningBellRadio -> "bell"
                R.id.warningCashRadio -> "cash"  // 修复：cash 而不是 beep
                R.id.warningCockRadio -> "cock"  // 修复：cock 而不是 chime
                else -> "bell"
            }
        }

        // 修复ID匹配问题
        drowsinessRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedDrowsinessSound = when (checkedId) {
                R.id.drowsinessAlarmRadio -> "alarm"
                R.id.drowsinessYayRadio -> "yay"    // 修复：yay 而不是 siren
                R.id.drowsinessUrgentRadio -> "urgent"
                else -> "alarm"
            }
        }

        testWarningButton.setOnClickListener {
            if (soundEnabled) {
                playTestSound(getWarningSoundResource(selectedWarningSound))
            } else {
                Toast.makeText(this, "Sound is disabled", Toast.LENGTH_SHORT).show()
            }
        }

        testDrowsinessButton.setOnClickListener {
            if (soundEnabled) {
                playTestSound(getDrowsinessSoundResource(selectedDrowsinessSound))
            } else {
                Toast.makeText(this, "Sound is disabled", Toast.LENGTH_SHORT).show()
            }
        }

        saveButton.setOnClickListener {
            saveSettings()
        }

        cancelButton.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun updateUIState() {
        val isEnabled = soundEnabled
        warningRadioGroup.isEnabled = isEnabled
        drowsinessRadioGroup.isEnabled = isEnabled
        testWarningButton.isEnabled = isEnabled
        testDrowsinessButton.isEnabled = isEnabled

        // Enable/disable all radio buttons
        for (i in 0 until warningRadioGroup.childCount) {
            warningRadioGroup.getChildAt(i).isEnabled = isEnabled
        }
        for (i in 0 until drowsinessRadioGroup.childCount) {
            drowsinessRadioGroup.getChildAt(i).isEnabled = isEnabled
        }
    }

    private fun getWarningSoundResource(soundType: String): Int {
        return when (soundType) {
            "bell" -> R.raw.warning_bell
            "cash" -> R.raw.warning_cash
            "cock" -> R.raw.warning_cock
            else -> R.raw.warning_bell
        }
    }

    private fun getDrowsinessSoundResource(soundType: String): Int {
        return when (soundType) {
            "alarm" -> R.raw.drowsiness_alarm
            "yay" -> R.raw.drowsiness_yay
            "urgent" -> R.raw.drowsiness_urgent
            else -> R.raw.drowsiness_alarm
        }
    }

    private fun playTestSound(resourceId: Int) {
        try {
            testMediaPlayer?.release()
            testMediaPlayer = MediaPlayer.create(this, resourceId)
            testMediaPlayer?.start()
            Toast.makeText(this, "Playing test sound", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // 如果音频文件不存在，使用备选方案
            Toast.makeText(this, "Audio file not found, using system sound", Toast.LENGTH_SHORT).show()
            playSystemSound()
        }
    }

    // 添加备选方案
    private fun playSystemSound() {
        try {
            testMediaPlayer?.release()
            testMediaPlayer?.start()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to play any sound: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveSettings() {
        val editor = sharedPreferences.edit()
        editor.putBoolean("sound_enabled", soundEnabled)
        editor.putString("warning_sound", selectedWarningSound)
        editor.putString("drowsiness_sound", selectedDrowsinessSound)
        editor.apply()

        Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show()
        setResult(RESULT_OK)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        testMediaPlayer?.release()
    }
}
package com.scentsafe.android_facial_landmark

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.pow
import kotlin.math.sqrt

data class Point2D(val x: Float, val y: Float)

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    // UI组件
    private lateinit var surfaceView: SurfaceView
    private lateinit var textureView: TextureView
    private lateinit var statusTextView: TextView
    private lateinit var detailsTextView: TextView
    private lateinit var heartRateButton: Button
    private lateinit var settingsButton: Button

    // 音效相关
    private var warningMediaPlayer: MediaPlayer? = null
    private var drowsinessMediaPlayer: MediaPlayer? = null
    private lateinit var sharedPreferences: SharedPreferences
    private var soundEnabled = true
    private var selectedWarningSound = "bell"
    private var selectedDrowsinessSound = "alarm"
    private var lastWarningPlayTime = 0L
    private var lastDrowsinessPlayTime = 0L
    private val SOUND_COOLDOWN = 3000L // 3 seconds cooldown between sounds

    // 相机和MediaPipe
    private lateinit var faceLandmarker: FaceLandmarker
    private lateinit var cameraManager: CameraManager
    private lateinit var cameraDevice: CameraDevice
    private lateinit var captureSession: CameraCaptureSession
    private lateinit var backgroundThread: HandlerThread
    private lateinit var backgroundHandler: Handler

    // Firebase - 增强连接管理
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var drowsinessRef: DatabaseReference
    private lateinit var heartRateRef: DatabaseReference
    private var firebaseConnected = false
    private var lastFirebaseUpdate = 0L
    private val FIREBASE_UPDATE_INTERVAL = 2000L
    private val FIREBASE_TIMEOUT_CHECK = 15000L
    private var lastFirebaseCheck = System.currentTimeMillis()
    private var firebaseInitialized = false

    // 电源管理
    private lateinit var powerManager: PowerManager
    private var wakeLock: PowerManager.WakeLock? = null

    // 蓝牙通信
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var bluetoothOutputStream: OutputStream? = null
    private val discoveredDevices = mutableListOf<BluetoothDevice>()
    private val listItems = mutableListOf<String>()
    private var devicesDialog: androidx.appcompat.app.AlertDialog? = null
    // 在“蓝牙通信”部分后面补充
    private var isBtConnected = false
    private var selectedBtDevice: BluetoothDevice? = null
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    // 心率监测相关（后台运行）
    private var sensorManager: SensorManager? = null
    private var heartRateSensor: Sensor? = null
    private var heartRateListener: SensorEventListener? = null
    private var currentHeartRate = 75
    private var lastHeartRateUpdate = 0L
    private val HEART_RATE_UPDATE_INTERVAL = 10000L
    private var heartRateMonitoringActive = false
    private var heartRateHandler: Handler? = null
    private var heartRateRunnable: Runnable? = null

    // 检测参数
    private val EAR_THRESH = 0.18
    private val MAR_THRESH = 0.65
    private val EYES_CLOSED_DURATION = 1500L
    private val YAWN_DURATION = 1000L
    private val YAWN_THRESH = 3
    private val BLINK_THRESH = 15
    private val RAPID_BLINK_THRESH = 8
    private val DROWSINESS_YAWN_THRESH = 5
    private val DROWSINESS_BLINK_THRESH = 25
    private val TIME_WINDOW = 60000L
    private val BLINK_TIME_WINDOW = 10000L
    private val RAPID_BLINK_WINDOW = 5000L

    // 状态变量
    private var currentState = "NORMAL"
    private var lastSentState: String? = null
    private var eyesClosedStartTime: Long? = null
    private var yawnStartTime: Long? = null
    private var yawnCount = 0
    private var blinkCount = 0
    private var rapidBlinkCount = 0
    private var resetTime = System.currentTimeMillis()
    private var blinkResetTime = System.currentTimeMillis()
    private var rapidBlinkResetTime = System.currentTimeMillis()

    private var wasEyesClosed = false
    private var wasYawning = false
    private var lastBlinkTime = 0L

    // 滑动窗口数据
    private val earHistory = mutableListOf<Double>()
    private val marHistory = mutableListOf<Double>()
    private val HISTORY_SIZE = 5

    // 检测敏感度设置
    private var baselineEAR = 0.0
    private var baselineMAR = 0.0
    private var isBaselineSet = false
    private var frameCount = 0
    private val BASELINE_FRAMES = 50

    private var currentEAR = 0.0
    private var currentMAR = 0.0
    private var currentEARThresh = EAR_THRESH
    private var currentMARThresh = MAR_THRESH

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val CAMERA_PERMISSION_CODE = 100
    private var frontCameraId: String? = null
    private var previewSize: Size? = null
    private var lastInferenceTimeMs = 0L
    private val INFERENCE_INTERVAL_MS = 50L
    private var timestampMs = 0L

    private var lastUIUpdateTime = 0L
    private val UI_UPDATE_INTERVAL = 200L
    // 放在 class MainActivity 内部，onCreate 之前的地方
    private val requestEnableBt =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                // 用户已开启蓝牙，继续弹设备列表
                showBluetoothDevicePickerInternal()
            } else {
                Toast.makeText(this, "Bluetooth not enabled", Toast.LENGTH_SHORT).show()
            }
        }

    private val requestBtPermissions =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val granted = grants.values.all { it }
            if (granted) {
                showBluetoothDevicePicker() // 继续流程
            } else {
                Toast.makeText(this, "Bluetooth permissions denied", Toast.LENGTH_SHORT).show()
            }
        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        initializeSharedPreferences()
        initializePowerManagement()
        initializeViews()
        initializeAudioSystem()
        initializeFirebase()
        initializeBluetooth()
        checkPermissions()
        startFirebaseMonitoring()
    }
    private fun setStateChipColor(state: String) {
        val chip = findViewById<TextView>(R.id.statusTextView)
        val bg = chip.background?.mutate()
        val color = when (state) {
            "NORMAL" -> getColorCompat(R.color.success)
            "WARNING" -> getColorCompat(R.color.warning)
            "DROWSINESS" -> getColorCompat(R.color.danger)
            else -> getColorCompat(R.color.brandPrimary)
        }
        if (bg is android.graphics.drawable.GradientDrawable) {
            bg.setColor(color)
        } else {
            // 用新的圆角 shape 动态设置
            val d = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 999f
                setColor(color)
            }
            chip.background = d
        }
    }

    private fun getColorCompat(resId: Int): Int =
        androidx.core.content.ContextCompat.getColor(this, resId)
    private fun initializeSharedPreferences() {
        sharedPreferences = getSharedPreferences("DrowsinessDetectionSettings", Context.MODE_PRIVATE)
        soundEnabled = sharedPreferences.getBoolean("sound_enabled", true)
        selectedWarningSound = sharedPreferences.getString("warning_sound", "bell") ?: "bell"
        selectedDrowsinessSound = sharedPreferences.getString("drowsiness_sound", "alarm") ?: "alarm"
    }

    private fun initializeAudioSystem() {
        try {
            loadSoundFiles()
            Log.d("Audio", "Audio system initialized successfully")
        } catch (e: Exception) {
            Log.e("Audio", "Failed to initialize audio system: ${e.message}")
        }
    }

    private fun loadSoundFiles() {
        try {
            // Load warning sounds
            warningMediaPlayer?.release()
            warningMediaPlayer = when (selectedWarningSound) {
                "bell" -> MediaPlayer.create(this, R.raw.warning_bell)
                "cash" -> MediaPlayer.create(this, R.raw.warning_cash)
                "cock" -> MediaPlayer.create(this, R.raw.warning_cock)
                else -> MediaPlayer.create(this, R.raw.warning_bell)
            }

            // Load drowsiness sounds
            drowsinessMediaPlayer?.release()
            drowsinessMediaPlayer = when (selectedDrowsinessSound) {
                "alarm" -> MediaPlayer.create(this, R.raw.drowsiness_alarm)
                "yay" -> MediaPlayer.create(this, R.raw.drowsiness_yay)
                "urgent" -> MediaPlayer.create(this, R.raw.drowsiness_urgent)
                else -> MediaPlayer.create(this, R.raw.drowsiness_alarm)
            }

            Log.d("Audio", "Sound files loaded: Warning=$selectedWarningSound, Drowsiness=$selectedDrowsinessSound")
        } catch (e: Exception) {
            Log.e("Audio", "Failed to load sound files: ${e.message}")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 200 && resultCode == RESULT_OK) {
            // Reload settings after returning from settings page
            initializeSharedPreferences()
            loadSoundFiles()
            Log.d("Settings", "Settings reloaded after returning from settings page")
        }
    }

    private fun playWarningSound() {
        if (!soundEnabled) return

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastWarningPlayTime < SOUND_COOLDOWN) return

        try {
            warningMediaPlayer?.let { player ->
                if (!player.isPlaying) {
                    player.start()
                    lastWarningPlayTime = currentTime
                    Log.d("Audio", "Playing warning sound: $selectedWarningSound")
                }
            }
        } catch (e: Exception) {
            Log.e("Audio", "Failed to play warning sound: ${e.message}")
        }
    }

    private fun playDrowsinessSound() {
        if (!soundEnabled) return

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastDrowsinessPlayTime < SOUND_COOLDOWN) return

        try {
            drowsinessMediaPlayer?.let { player ->
                if (!player.isPlaying) {
                    player.start()
                    lastDrowsinessPlayTime = currentTime
                    Log.d("Audio", "Playing drowsiness sound: $selectedDrowsinessSound")
                }
            }
        } catch (e: Exception) {
            Log.e("Audio", "Failed to play drowsiness sound: ${e.message}")
        }
    }

    private fun initializePowerManagement() {
        try {
            powerManager = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "DrowsinessDetection:WakeLock"
            )
            wakeLock?.acquire(10*60*1000L)
            Log.d("PowerManager", "WakeLock has been acquired")
        } catch (e: Exception) {
            Log.e("PowerManager", "WakeLock acquisition failed: ${e.message}")
        }
    }

    private fun initializeViews() {
        surfaceView = findViewById(R.id.surfaceView)
        textureView = findViewById(R.id.textureView)
        statusTextView = findViewById(R.id.statusTextView)
        detailsTextView = findViewById(R.id.detailsTextView)
        heartRateButton = findViewById(R.id.heartRateButton)
        settingsButton = findViewById(R.id.settingsButton)
        // 在 findViewById 后追加
        val bluetoothButton: Button = findViewById(R.id.bluetoothButton)
        bluetoothButton.setOnClickListener { showBluetoothDevicePicker() }

        heartRateButton.setOnClickListener {
            val intent = Intent(this, HeartRateActivity::class.java)
            startActivity(intent)
        }

        settingsButton.setOnClickListener {
            val intent = Intent(this, SoundSettingsActivity::class.java)
            startActivityForResult(intent, 200)
        }

        surfaceView.holder.addCallback(this)
        surfaceView.setZOrderOnTop(true)
        surfaceView.holder.setFormat(PixelFormat.TRANSLUCENT)
        textureView.surfaceTextureListener = textureListener

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        updateUIImmediate()
        setStateChipColor(currentState)

        // 初始蓝牙点颜色
        findViewById<View>(R.id.btDot).background.setTint(Color.parseColor("#66FFFFFF"))
    }
    private val discoveryReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action ?: return
            when (action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    device?.let { onDeviceFound(it) }
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Scan finished", Toast.LENGTH_SHORT).show()
                    }
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    val state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.BOND_NONE)
                    val prev = intent.getIntExtra(BluetoothDevice.EXTRA_PREVIOUS_BOND_STATE, BluetoothDevice.BOND_NONE)
                    Log.d("Bluetooth", "Bond state: ${device?.address} $prev -> $state")
                    if (state == BluetoothDevice.BOND_BONDED && device != null) {
                        // 配对完成后自动连接
                        connectToEsp32(device)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val f = android.content.IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        registerReceiver(discoveryReceiver, f)
    }

    override fun onStop() {
        try {
            unregisterReceiver(discoveryReceiver)
        } catch (_: Exception) {}
        super.onStop()
    }
    private fun showBluetoothDevicePicker() {
        val adapter = bluetoothAdapter ?: run {
            Toast.makeText(this, "This device does not support Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }

        val perms = mutableListOf<String>()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                perms += Manifest.permission.BLUETOOTH_CONNECT
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                perms += Manifest.permission.BLUETOOTH_SCAN
            }
        } else {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                perms += Manifest.permission.BLUETOOTH
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
                perms += Manifest.permission.BLUETOOTH_ADMIN
            }
        }
        // 扫描需要定位权限（Android 6+）
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            perms += Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (perms.isNotEmpty()) {
            requestBtPermissions.launch(perms.toTypedArray())
            return
        }

        if (!adapter.isEnabled) {
            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            requestEnableBt.launch(intent)
            return
        }

        // 打开设备选择弹窗并开始扫描
        openDevicesDialogAndScan()
    }

    private fun openDevicesDialogAndScan() {
        val adapter = bluetoothAdapter ?: return

        // 准备数据：已配对 + 清空发现列表
        discoveredDevices.clear()
        listItems.clear()
        val bonded = (if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            emptySet()
        } else {
            adapter.bondedDevices ?: emptySet()
        }).toList()

        if (bonded.isNotEmpty()) {
            listItems += bonded.map { "${it.name ?: "Unknown"} (${it.address ?: "N/A"})  • Paired" }
            discoveredDevices += bonded
        }

        val listAdapter = object : android.widget.BaseAdapter() {
            override fun getCount() = listItems.size
            override fun getItem(position: Int) = listItems[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val tv = (convertView as? android.widget.TextView)
                    ?: android.widget.TextView(parent.context).apply {
                        setPadding(32, 28, 32, 28)
                        textSize = 16f
                    }
                tv.text = listItems[position]
                return tv
            }
        }

        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Select or scan ESP32")
            .setAdapter(listAdapter) { dlg, which ->
                val dev = discoveredDevices.getOrNull(which)
                if (dev != null) {
                    // 未配对则先配对
                    if (dev.bondState != BluetoothDevice.BOND_BONDED) {
                        pairDevice(dev)
                    } else {
                        connectToEsp32(dev)
                    }
                }
            }
            .setNegativeButton("Close") { dlg, _ ->
                stopDiscovery()
                dlg.dismiss()
                devicesDialog = null
            }
            .setPositiveButton("Scan nearby") { _, _ -> } // 稍后替换点击逻辑
        devicesDialog = builder.create()
        devicesDialog?.setOnShowListener {
            // 替换“Scan nearby”为自定义点击，重复触发可重新扫描
            devicesDialog?.getButton(android.app.AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                startDiscovery(listAdapter)
            }
        }
        devicesDialog?.show()

        // 自动开始一次扫描
        startDiscovery(listAdapter)
    }

    private fun startDiscovery(listAdapter: android.widget.BaseAdapter) {
        val adapter = bluetoothAdapter ?: return
        stopDiscovery()

        // 清空“未配对发现”的追加项（保留已配对）
        val keep = discoveredDevices.filter { it.bondState == BluetoothDevice.BOND_BONDED }
        discoveredDevices.clear()
        discoveredDevices += keep
        listItems.retainAll { it.contains("• Paired") }
        listAdapter.notifyDataSetChanged()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
        ) return

        val started = adapter.startDiscovery()
        Toast.makeText(this, if (started) "Scanning..." else "Scan start failed", Toast.LENGTH_SHORT).show()
    }

    private fun stopDiscovery() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
        ) return
        bluetoothAdapter?.takeIf { it.isDiscovering }?.cancelDiscovery()
    }

    private fun onDeviceFound(device: BluetoothDevice) {
        // 去重
        val exists = discoveredDevices.any { it.address == device.address }
        if (exists) return

        discoveredDevices += device

        // 默认值
        var name = "Unknown"
        var bonded = false

        // Android 12+ 访问 name/bondState 需要 BLUETOOTH_CONNECT；低版本也统一做检查更稳妥
        val hasConnectPerm =
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S)
                ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            else true

        if (hasConnectPerm) {
            // 可能仍然为 null，用 ?: 兜底
            name = device.name ?: "Unknown"
            bonded = device.bondState == BluetoothDevice.BOND_BONDED
        } else {
            // 无权限时避免直接访问，使用地址作为标题
            name = "Device"
            bonded = false
        }

        val addr = device.address ?: "N/A"
        val label = "$name ($addr)  • ${if (bonded) "Paired" else "New"}"
        listItems += label

        runOnUiThread {
            (devicesDialog?.listView?.adapter as? android.widget.BaseAdapter)?.notifyDataSetChanged()
        }
    }

    private fun pairDevice(device: BluetoothDevice) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) return

        try {
            Toast.makeText(this, "Pairing ${device.name ?: device.address}", Toast.LENGTH_SHORT).show()
            // 发起配对
            val ok = device.createBond()
            Log.d("Bluetooth", "createBond: $ok")
        } catch (e: Exception) {
            Log.e("Bluetooth", "Pair failed: ${e.message}")
            Toast.makeText(this, "Pair failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showBluetoothDevicePickerInternal() {
        val adapter = bluetoothAdapter ?: return

        // Android 12+ 调用前再次校验权限，避免 Lint 报 RequiresPermission
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            // 正常情况下这里不会走到，因为前面已经请求过权限；保险起见再返回一下
            Toast.makeText(this, "Missing BLUETOOTH_CONNECT permission", Toast.LENGTH_SHORT).show()
            return
        }

        // bondedDevices 可能为 null，先取为集合
        val bondedSet: Set<BluetoothDevice> = adapter.bondedDevices ?: emptySet()
        val bonded = bondedSet.toList()

        if (bonded.isEmpty()) {
            Toast.makeText(this, "No paired devices. Pair your ESP32 first.", Toast.LENGTH_LONG).show()
            startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }

        // name/address 可能为 null，提供默认值
        val names: Array<String> = bonded.map { dev ->
            val n = dev.name ?: "Unknown"
            val addr = dev.address ?: "N/A"
            "$n ($addr)"
        }.toTypedArray()

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Select ESP32")
            .setItems(names) { dlg, which ->
                val dev = bonded.getOrNull(which)
                if (dev != null) {
                    connectToEsp32(dev)
                } else {
                    Toast.makeText(this, "Invalid selection", Toast.LENGTH_SHORT).show()
                }
                dlg.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun connectToEsp32(device: BluetoothDevice) {
        scope.launch(Dispatchers.IO) {
            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                    ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) return@launch

                bluetoothSocket?.close()
                val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)

                // 停止扫描避免连接变慢
                bluetoothAdapter?.cancelDiscovery()

                socket.connect()
                bluetoothSocket = socket
                bluetoothOutputStream = socket.outputStream
                selectedBtDevice = device
                isBtConnected = true

                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Connected: ${device.name}", Toast.LENGTH_SHORT).show()
                }
                Log.d("Bluetooth", "SPP connected to ${device.address}")
            } catch (e: IOException) {
                isBtConnected = false
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "BT connect failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
                Log.e("Bluetooth", "Connect error", e)
                try { bluetoothSocket?.close() } catch (_: Exception) {}
            }
        }
    }
    // ========== 后台心率监测初始化 ==========
    private fun initializeHeartRateMonitoring() {
        try {
            Log.d("HeartRate", "Start background heart rate monitoring initialization")
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            heartRateSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_HEART_RATE)

            // 初始化默认心率数据到Firebase
            updateHeartRateToFirebase(75, false)

            if (heartRateSensor != null) {
                Log.d("HeartRate", "The device supports heart rate sensor (running in the background)")
            } else {
                Log.w("HeartRate", "The device does not support heart rate sensor, use the default value")
            }
        } catch (e: Exception) {
            Log.e("HeartRate", "Background heart rate monitoring initialization failed: ${e.message}")
        }
    }

    // 新增：单独更新心率数据到 heartRate_value 节点
    private fun updateHeartRateToFirebase(bpm: Int, monitoring: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                val heartRateData = mapOf(
                    "bpm" to bpm,
                    "timestamp" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date()),
                    "lastUpdate" to ServerValue.TIMESTAMP,
                    "isMonitoring" to monitoring,
                    "deviceSupportsHeartRate" to (heartRateSensor != null),
                    "source" to if (monitoring) "sensor" else "default"
                )

                heartRateRef.setValue(heartRateData)
                    .addOnSuccessListener {
                        Log.d("Firebase", "Heart rate data updated successfully: $bpm BPM")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "Heart rate data update failed: ${exception.message}")
                    }
            } catch (e: Exception) {
                Log.e("Firebase", "Heart rate data update abnormality: ${e.message}")
            }
        }
    }

    private fun initializeFirebase() {
        try {
            // 确保Firebase只初始化一次
            if (!firebaseInitialized) {
                firebaseDatabase = FirebaseDatabase.getInstance("https://scentsafe-17cfd-default-rtdb.asia-southeast1.firebasedatabase.app/")

                // 启用离线持久化（只能调用一次）
                try {
                    firebaseDatabase.setPersistenceEnabled(true)
                    Log.d("Firebase", "Persistence Enabled")
                } catch (e: Exception) {
                    Log.w("Firebase", "Persistence enablement failed or has been enabled: ${e.message}")
                }

                drowsinessRef = firebaseDatabase.getReference("drowsiness_status")
                heartRateRef = firebaseDatabase.getReference("heartRate_value") // 新增心率节点

                // 保持连接活跃
                drowsinessRef.keepSynced(true)
                heartRateRef.keepSynced(true)

                firebaseInitialized = true
            }

            // 设置连接状态监听
            val connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected")
            connectedRef.addValueEventListener(object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    val wasConnected = firebaseConnected
                    firebaseConnected = snapshot.getValue(Boolean::class.java) ?: false
                    Log.d("Firebase", "Connection Status: $firebaseConnected")

                    // 只在状态改变时显示Toast
                    if (wasConnected != firebaseConnected) {
                        runOnUiThread {
                            if (firebaseConnected) {
                                Toast.makeText(this@MainActivity, "Firebase Connected", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "Firebase Disconnected", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                    Log.e("Firebase", "Connection status monitoring failed: ${error.message}")
                }
            })

            Log.d("Firebase", "Firebase initialization succeeded")

        } catch (e: Exception) {
            Log.e("Firebase", "Firebase initialization failed: ${e.message}")
            runOnUiThread {
                Toast.makeText(this, "Firebase initialization failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // 启动Firebase连接监控
    private fun startFirebaseMonitoring() {
        scope.launch {
            while (isActive) {
                delay(FIREBASE_TIMEOUT_CHECK)

                val currentTime = System.currentTimeMillis()
                if (currentTime - lastFirebaseUpdate > FIREBASE_TIMEOUT_CHECK * 2) {
                    Log.w("Firebase", "Firebase update timed out, trying to reconnect...")
                    reconnectFirebase()
                }

                // 发送心跳包保持连接
                sendFirebaseHeartbeat()
            }
        }
    }

    private fun reconnectFirebase() {
        scope.launch(Dispatchers.IO) {
            try {
                Log.d("Firebase", "Reinitializing Firebase connection...")

                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Reconnecting to Firebase...", Toast.LENGTH_SHORT).show()
                }

                firebaseDatabase.goOffline()
                delay(3000) // 等待3秒
                firebaseDatabase.goOnline()

                Log.d("Firebase", "Firebase reconnection completed")

            } catch (e: Exception) {
                Log.e("Firebase", "Firebase reconnection failed: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Firebase reconnection failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun sendFirebaseHeartbeat() {
        scope.launch(Dispatchers.IO) {
            try {
                if (::firebaseDatabase.isInitialized) {
                    val heartbeatRef = firebaseDatabase.getReference("heartbeat")
                    heartbeatRef.setValue(ServerValue.TIMESTAMP)
                        .addOnSuccessListener {
                            Log.d("Firebase", "Heartbeat packet sent successfully")
                        }
                        .addOnFailureListener { exception ->
                            Log.e("Firebase", "Heartbeat packet sent successfully: ${exception.message}")
                        }
                }
            } catch (e: Exception) {
                Log.e("Firebase", "Heartbeat packet abnormality: ${e.message}")
            }
        }
    }

    private fun initializeBluetooth() {
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            Log.w("Bluetooth", "The device does not support Bluetooth")
        }
    }

    private fun checkPermissions() {
        val permissionsNeeded = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CAMERA)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WAKE_LOCK) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.WAKE_LOCK)
        }

        // 添加心率权限
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.BODY_SENSORS)
        }
        // 位置权限用于扫描
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        // 扫描需要定位：请求 FINE 即可（授予后等同于也有 COARSE）
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_ADMIN)
            }
        }

        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toTypedArray(), CAMERA_PERMISSION_CODE)
        } else {
            setupCamera()
            initializeHeartRateMonitoring() // 添加后台心率监测初始化
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                setupCamera()
                initializeHeartRateMonitoring() // 添加后台心率监测初始化
            } else {
                Toast.makeText(this, "Camera, Bluetooth and sensor permissions are required for normal use", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val textureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
            openCamera()
        }
        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastInferenceTimeMs >= INFERENCE_INTERVAL_MS) {
                lastInferenceTimeMs = currentTime
                processFrame()
            }
        }
    }

    private fun setupCamera() {
        findFrontCamera()
        initFaceLandmarker()
        startBackgroundThread()
    }

    private fun findFrontCamera() {
        try {
            for (cameraId in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    frontCameraId = cameraId
                    val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
                    previewSize = sizes?.find { it.width == 1280 && it.height == 720 }
                        ?: sizes?.find { it.width == 640 && it.height == 480 }
                                ?: sizes?.firstOrNull()
                    break
                }
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun initFaceLandmarker() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("face_landmarker.task")
                .build()

            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.6f)
                .setMinFacePresenceConfidence(0.6f)
                .setMinTrackingConfidence(0.7f)
                .setResultListener { result: FaceLandmarkerResult, input: MPImage ->
                    runOnUiThread {
                        processDrowsinessDetection(result, input)
                        displayResults(result, input)
                    }
                }
                .setErrorListener { error ->
                    runOnUiThread {
                        Toast.makeText(this, "Face detection error: ${error.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                .build()

            faceLandmarker = FaceLandmarker.createFromOptions(this, options)
            Toast.makeText(this, "Sleepiness detection system is ready", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to initialize the face detection system: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // 优化后的嗜睡检测逻辑
    private fun processDrowsinessDetection(result: FaceLandmarkerResult, input: MPImage) {
        if (result.faceLandmarks().isEmpty()) {
            resetDetectionState()
            return
        }

        val landmarks = result.faceLandmarks()[0]
        frameCount++

        val ear = calculateEAR(landmarks)
        val mar = calculateMAR(landmarks)

        currentEAR = ear
        currentMAR = mar

        establishBaseline(ear, mar)
        addToHistory(ear, mar)
        val smoothEAR = getSmoothedEAR()
        val smoothMAR = getSmoothedMAR()

        val currentTime = System.currentTimeMillis()

        currentEARThresh = if (isBaselineSet) baselineEAR * 0.70 else EAR_THRESH
        currentMARThresh = if (isBaselineSet) baselineMAR * 1.4 else MAR_THRESH

        detectYawnSensitive(smoothMAR, currentMARThresh, currentTime)
        detectBlinkPatterns(smoothEAR, currentEARThresh, currentTime)

        resetCounters(currentTime)
        updateDrowsinessState(smoothEAR, smoothMAR, currentEARThresh, currentMARThresh)

        if (currentTime - lastUIUpdateTime >= UI_UPDATE_INTERVAL) {
            updateUIImmediate()
            lastUIUpdateTime = currentTime
        }

        // 优化Firebase更新频率和重试机制
        if (currentState != lastSentState || currentTime - lastFirebaseUpdate >= FIREBASE_UPDATE_INTERVAL) {
            updateFirebaseWithRetry(smoothEAR, smoothMAR)
            sendToBluetooth(currentState)
            lastSentState = currentState
        }
    }

    private fun resetDetectionState() {
        wasEyesClosed = false
        wasYawning = false
        eyesClosedStartTime = null
        yawnStartTime = null
    }

    private fun establishBaseline(ear: Double, mar: Double) {
        if (!isBaselineSet && frameCount <= BASELINE_FRAMES) {
            baselineEAR = (baselineEAR * (frameCount - 1) + ear) / frameCount
            baselineMAR = (baselineMAR * (frameCount - 1) + mar) / frameCount

            if (frameCount == BASELINE_FRAMES) {
                isBaselineSet = true
                Log.d("Baseline", "Baseline established - EAR: $baselineEAR, MAR: $baselineMAR")
                runOnUiThread {
                    Toast.makeText(this, "Personal baseline calibration completed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun detectYawnSensitive(mar: Double, threshold: Double, currentTime: Long) {
        if (mar >= threshold) {
            if (!wasYawning) {
                yawnStartTime = currentTime
                wasYawning = true
                Log.d("Yawn", "Start yawning: MAR = $mar")
            }
        } else {
            if (wasYawning && yawnStartTime != null) {
                val yawnDuration = currentTime - yawnStartTime!!
                if (yawnDuration >= YAWN_DURATION) {
                    yawnCount++
                    Log.d("Yawn", "Yawn detected! Continue: ${yawnDuration}ms, count: $yawnCount")
                }
                wasYawning = false
                yawnStartTime = null
            }
        }
    }

    private fun detectBlinkPatterns(ear: Double, threshold: Double, currentTime: Long) {
        if (ear < threshold) {
            if (!wasEyesClosed) {
                wasEyesClosed = true
                eyesClosedStartTime = currentTime
            }
        } else {
            if (wasEyesClosed) {
                blinkCount++

                if (currentTime - lastBlinkTime < 400) {
                    rapidBlinkCount++
                    Log.d("RapidBlink", "Rapid Blink Detection: $rapidBlinkCount")
                }

                lastBlinkTime = currentTime
                wasEyesClosed = false
                eyesClosedStartTime = null

                Log.d("Blink", "Blink Detection: Total $blinkCount, Rapid $rapidBlinkCount")
            }
        }

        eyesClosedStartTime?.let { startTime ->
            if (currentTime - startTime >= EYES_CLOSED_DURATION) {
                Log.d("LongBlink", "Closing eyes for a long time: ${currentTime - startTime}ms")
                currentState = "DROWSINESS"
            }
        }
    }

    private fun addToHistory(ear: Double, mar: Double) {
        earHistory.add(ear)
        marHistory.add(mar)

        if (earHistory.size > HISTORY_SIZE) {
            earHistory.removeAt(0)
        }
        if (marHistory.size > HISTORY_SIZE) {
            marHistory.removeAt(0)
        }
    }

    private fun getSmoothedEAR(): Double {
        return if (earHistory.isNotEmpty()) {
            earHistory.average()
        } else 0.3
    }

    private fun getSmoothedMAR(): Double {
        return if (marHistory.isNotEmpty()) {
            marHistory.average()
        } else 0.3
    }

    private fun resetCounters(currentTime: Long) {
        if (currentTime - resetTime > TIME_WINDOW) {
            yawnCount = 0
            blinkCount = 0
            resetTime = currentTime
            Log.d("Reset", "Reset the main counter")
        }

        if (currentTime - blinkResetTime > BLINK_TIME_WINDOW) {
            blinkResetTime = currentTime
        }

        if (currentTime - rapidBlinkResetTime > RAPID_BLINK_WINDOW) {
            rapidBlinkCount = 0
            rapidBlinkResetTime = currentTime
        }
    }

    private fun updateDrowsinessState(ear: Double, mar: Double, earThresh: Double, marThresh: Double) {
        val previousState = currentState

        currentState = when {
            yawnCount >= DROWSINESS_YAWN_THRESH ||
                    blinkCount >= DROWSINESS_BLINK_THRESH ||
                    rapidBlinkCount >= (RAPID_BLINK_THRESH * 2) ||
                    wasYawning && (System.currentTimeMillis() - (yawnStartTime ?: 0)) > 2000 -> {
                "DROWSINESS"
            }

            yawnCount >= YAWN_THRESH ||
                    blinkCount >= BLINK_THRESH ||
                    rapidBlinkCount >= RAPID_BLINK_THRESH ||
                    wasYawning -> {
                "WARNING"
            }

            else -> "NORMAL"
        }

        // Play sound when state changes
        if (currentState != previousState) {
            when (currentState) {
                "WARNING" -> playWarningSound()
                "DROWSINESS" -> playDrowsinessSound()
            }
        }
    }
    // ========== 修改UI显示，移除心率信息 ==========
    private fun updateUIImmediate() {
        setStateChipColor(currentState)

        // 蓝牙连接点
        val btDot = findViewById<View>(R.id.btDot)
        btDot.background?.mutate()?.setTint(
            if (isBtConnected) getColorCompat(R.color.success) else Color.parseColor("#66FFFFFF")
        )
        runOnUiThread {
            try {
                statusTextView.text = "State: $currentState"
                statusTextView.setTextColor(when (currentState) {
                    "NORMAL" -> Color.GREEN
                    "WARNING" -> Color.YELLOW
                    "DROWSINESS" -> Color.RED
                    else -> Color.WHITE
                })

                val connectionStatus = if (firebaseConnected) "Connected" else "Connection lost"
                val lastUpdateStr = if (lastFirebaseUpdate > 0) {
                    val timeDiff = (System.currentTimeMillis() - lastFirebaseUpdate) / 1000
                    "${timeDiff}Seconds ago"
                } else "Not updated"

                // 移除心率显示，只保留嗜睡检测数据
                val detailText = if (isBaselineSet) {
                    """EAR: %.3f / %.3f (Baseline: %.3f)
MAR: %.3f / %.3f (Baseline: %.3f)
Firebase: $connectionStatus | Last Updated: $lastUpdateStr
Blinking: $blinkCount | Rapid: $rapidBlinkCount
Yawning: $yawnCount | State: ${if(wasYawning) "Progressing" else "Normal"}
Processing frames: $frameCount""".format(
                        currentEAR, currentEARThresh, baselineEAR,
                        currentMAR, currentMARThresh, baselineMAR
                    )
                } else {
                    """EAR: %.3f / %.3f (Calibrating...)
MAR: %.3f / %.3f (Calibrating...)
Firebase: $connectionStatus | 上次更新: $lastUpdateStr
Blinking: $blinkCount | Rapid: $rapidBlinkCount
Yawning: $yawnCount | State: ${if(wasYawning) "Progressing" else "Normal"}
Calibration progress: $frameCount/$BASELINE_FRAMES""".format(
                        currentEAR, currentEARThresh,
                        currentMAR, currentMARThresh
                    )
                }

                detailsTextView.text = detailText

            } catch (e: Exception) {
                Log.e("UI", "UI update error: ${e.message}")
            }
        }
    }

    private fun calculateEAR(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Double {
        try {
            val leftEyePoints = listOf(
                Point2D(landmarks[33].x(), landmarks[33].y()),
                Point2D(landmarks[160].x(), landmarks[160].y()),
                Point2D(landmarks[158].x(), landmarks[158].y()),
                Point2D(landmarks[133].x(), landmarks[133].y()),
                Point2D(landmarks[153].x(), landmarks[153].y()),
                Point2D(landmarks[144].x(), landmarks[144].y())
            )

            val rightEyePoints = listOf(
                Point2D(landmarks[362].x(), landmarks[362].y()),
                Point2D(landmarks[385].x(), landmarks[385].y()),
                Point2D(landmarks[387].x(), landmarks[387].y()),
                Point2D(landmarks[263].x(), landmarks[263].y()),
                Point2D(landmarks[373].x(), landmarks[373].y()),
                Point2D(landmarks[380].x(), landmarks[380].y())
            )

            val leftEAR = calculateEnhancedEAR(leftEyePoints)
            val rightEAR = calculateEnhancedEAR(rightEyePoints)

            return (leftEAR + rightEAR) / 2.0
        } catch (e: Exception) {
            Log.e("EAR", "EAR calculation error: ${e.message}")
            return 0.3
        }
    }

    private fun calculateEnhancedEAR(eyePoints: List<Point2D>): Double {
        val vertical1 = distance(eyePoints[1], eyePoints[5])
        val vertical2 = distance(eyePoints[2], eyePoints[4])
        val horizontal = distance(eyePoints[0], eyePoints[3])

        return if (horizontal > 0) {
            (vertical1 + vertical2) / (2.0 * horizontal)
        } else 0.0
    }

    private fun calculateMAR(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Double {
        try {
            val upperLip = Point2D(landmarks[13].x(), landmarks[13].y())
            val lowerLip = Point2D(landmarks[14].x(), landmarks[14].y())
            val leftCorner = Point2D(landmarks[61].x(), landmarks[61].y())
            val rightCorner = Point2D(landmarks[291].x(), landmarks[291].y())

            val upperLip2 = Point2D(landmarks[12].x(), landmarks[12].y())
            val lowerLip2 = Point2D(landmarks[15].x(), landmarks[15].y())

            val vertical1 = distance(upperLip, lowerLip)
            val vertical2 = distance(upperLip2, lowerLip2)
            val avgVertical = (vertical1 + vertical2) / 2.0

            val horizontal = distance(leftCorner, rightCorner)

            return if (horizontal > 0) avgVertical / horizontal else 0.0
        } catch (e: Exception) {
            Log.e("MAR", "MAR calculation error: ${e.message}")
            return 0.3
        }
    }

    private fun distance(p1: Point2D, p2: Point2D): Double {
        return sqrt((p1.x - p2.x).toDouble().pow(2) + (p1.y - p2.y).toDouble().pow(2))
    }

    // ========== 修改Firebase更新，分离心率数据 ==========
    private fun updateFirebaseWithRetry(ear: Double, mar: Double) {
        scope.launch(Dispatchers.IO) {
            try {
                // 主要嗜睡检测数据（不包含心率）
                val drowsinessData = mapOf(
                    "blinkCount" to blinkCount,
                    "eyeAspectRatio" to ear,
                    "mouthAspectRatio" to mar,
                    "state" to currentState,
                    "timestamp" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date()),
                    "yawnCount" to yawnCount,
                    "lastUpdate" to ServerValue.TIMESTAMP,
                    "frameCount" to frameCount,
                    "appVersion" to "1.0.0"
                )

                drowsinessRef.setValue(drowsinessData)
                    .addOnSuccessListener {
                        lastFirebaseUpdate = System.currentTimeMillis()
                        Log.d("Firebase", "Successfully updated sleepiness detection data")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "Sleepiness detection data update failed: ${exception.message}")
                        retryFirebaseUpdate(drowsinessData, 1, 3)
                    }

                // 心率数据单独更新到 heartRate_value 节点
                updateHeartRateToFirebase(currentHeartRate, heartRateMonitoringActive)

            } catch (e: Exception) {
                Log.e("Firebase", "Firebase operation exception: ${e.message}")
            }
        }
    }

    // 修复的递归重试函数
    private fun retryFirebaseUpdate(data: Map<String, Any>, currentRetry: Int, maxRetries: Int) {
        if (currentRetry > maxRetries) {
            Log.e("Firebase", "Firebase update finally failed, retried $maxRetries 次")
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Firebase connection failed, reconnecting...", Toast.LENGTH_SHORT).show()
            }
            reconnectFirebase()
            return
        }

        // 使用 Handler 替代 delay
        Handler(Looper.getMainLooper()).postDelayed({
            scope.launch(Dispatchers.IO) {
                try {
                    drowsinessRef.setValue(data)
                        .addOnSuccessListener {
                            lastFirebaseUpdate = System.currentTimeMillis()
                            Log.d("Firebase", "Retry to update Firebase successfully (retry number $currentRetry)")
                        }
                        .addOnFailureListener { exception ->
                            Log.e("Firebase", "Retry No. $currentRetry failed: ${exception.message}")
                            retryFirebaseUpdate(data, currentRetry + 1, maxRetries)
                        }
                } catch (e: Exception) {
                    Log.e("Firebase", "An exception occurred while retrying: ${e.message}")
                    retryFirebaseUpdate(data, currentRetry + 1, maxRetries)
                }
            }
        }, (1000 * currentRetry).toLong()) // 指数退避延迟
    }

    private fun sendToBluetooth(state: String) {
        val level = when (state) {
            "NORMAL" -> 0
            "WARNING" -> 1
            "DROWSINESS" -> 2
            else -> 0
        }
        scope.launch(Dispatchers.IO) {
            try {
                if (!isBtConnected || bluetoothOutputStream == null) return@launch
                val payload = "$level\n".toByteArray()
                bluetoothOutputStream!!.write(payload)
                bluetoothOutputStream!!.flush()
                Log.d("Bluetooth", "Sent fatigue level: $level")
            } catch (e: IOException) {
                Log.e("Bluetooth", "Send failed: ${e.message}")
                isBtConnected = false
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "BT disconnected", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun connectBluetooth(deviceAddress: String) {
        scope.launch(Dispatchers.IO) {
            try {
                if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    return@launch
                }
                val device: BluetoothDevice = bluetoothAdapter!!.getRemoteDevice(deviceAddress)
                bluetoothSocket = device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                bluetoothSocket?.connect()
                bluetoothOutputStream = bluetoothSocket?.outputStream
                Log.d("Bluetooth", "Bluetooth connection successful")
            } catch (e: IOException) {
                Log.e("Bluetooth", "Bluetooth connection failed: ${e.message}")
            }
        }
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread.looper)
    }

    private fun stopBackgroundThread() {
        if (::backgroundThread.isInitialized) {
            backgroundThread.quitSafely()
            try {
                backgroundThread.join()
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    private fun openCamera() {
        frontCameraId?.let { cameraId ->
            try {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    return
                }

                cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) {
                        cameraDevice = camera
                        createCameraPreviewSession()
                    }

                    override fun onDisconnected(camera: CameraDevice) {
                        camera.close()
                    }

                    override fun onError(camera: CameraDevice, error: Int) {
                        camera.close()
                        Toast.makeText(this@MainActivity, "Camera startup failed", Toast.LENGTH_SHORT).show()
                    }
                }, backgroundHandler)
            } catch (e: CameraAccessException) {
                e.printStackTrace()
            }
        }
    }

    private fun createCameraPreviewSession() {
        try {
            val texture = textureView.surfaceTexture
            previewSize?.let { size ->
                texture?.setDefaultBufferSize(size.width, size.height)
            }

            val surface = Surface(texture)
            val previewRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewRequestBuilder.addTarget(surface)

            cameraDevice.createCaptureSession(
                listOf(surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        updatePreview(previewRequestBuilder)
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Toast.makeText(this@MainActivity, "Camera configuration failed", Toast.LENGTH_SHORT).show()
                    }
                },
                null
            )
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun updatePreview(previewRequestBuilder: CaptureRequest.Builder) {
        try {
            previewRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            previewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            captureSession.setRepeatingRequest(previewRequestBuilder.build(), null, backgroundHandler)
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun processFrame() {
        if (!::faceLandmarker.isInitialized) return

        scope.launch(Dispatchers.IO) {
            try {
                val bitmap = textureView.getBitmap() ?: return@launch

                val argbBitmap = if (bitmap.config == Bitmap.Config.ARGB_8888) {
                    bitmap
                } else {
                    bitmap.copy(Bitmap.Config.ARGB_8888, false)
                }

                val mpImage = BitmapImageBuilder(argbBitmap).build()
                timestampMs = System.currentTimeMillis()
                faceLandmarker.detectAsync(mpImage, timestampMs)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // ========== 修改画布显示，移除心率显示 ==========
    private fun displayResults(result: FaceLandmarkerResult, input: MPImage) {
        try {
            val width = textureView.width
            val height = textureView.height

            if (width <= 0 || height <= 0) return

            val statusPaint = Paint().apply {
                textSize = 48f
                isAntiAlias = true
                color = when (currentState) {
                    "NORMAL" -> Color.GREEN
                    "WARNING" -> Color.YELLOW
                    "DROWSINESS" -> Color.RED
                    else -> Color.WHITE
                }
                style = Paint.Style.FILL
                setShadowLayer(4f, 2f, 2f, Color.BLACK)
            }

            val landmarkPaint = Paint().apply {
                color = Color.argb(255, 0, 255, 127)
                style = Paint.Style.FILL
                strokeWidth = 2f
                isAntiAlias = true
            }

            val eyeLandmarkPaint = Paint().apply {
                color = if (wasEyesClosed) Color.RED else Color.CYAN
                style = Paint.Style.FILL
                strokeWidth = 4f
                isAntiAlias = true
            }

            val mouthLandmarkPaint = Paint().apply {
                color = if (wasYawning) Color.RED else Color.YELLOW
                style = Paint.Style.FILL
                strokeWidth = 4f
                isAntiAlias = true
            }

            val holder: SurfaceHolder = surfaceView.holder
            val canvas = holder.lockCanvas() ?: return

            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

            val detailPaint = Paint().apply {
                textSize = 28f
                color = Color.WHITE
                setShadowLayer(2f, 1f, 1f, Color.BLACK)
            }
            // 移除心率显示
            canvas.drawText("Blinking: $blinkCount | Yawning: $yawnCount | Firebase: ${if(firebaseConnected) "✓" else "✗"}", 50f, 150f, detailPaint)

            result.faceLandmarks().forEach { landmarks ->
                landmarks.forEachIndexed { landmarkIndex, landmark ->
                    val x = landmark.x() * width
                    val y = landmark.y() * height

                    val (paint, radius) = when {
                        isMouthLandmark(landmarkIndex) -> Pair(mouthLandmarkPaint, 5f)
                        isEyeLandmark(landmarkIndex) -> Pair(eyeLandmarkPaint, 5f)
                        else -> Pair(landmarkPaint, 2f)
                    }

                    canvas.drawCircle(x, y, radius, paint)
                }
            }

            holder.unlockCanvasAndPost(canvas)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun isMouthLandmark(index: Int): Boolean {
        val mouthIndices = setOf(
            0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175,
            61, 84, 17, 314, 405, 320, 307, 375, 321, 308, 324, 318, 402, 317,
            14, 87, 178, 88, 95, 78, 191, 80, 81, 82, 13, 312, 311, 310, 415,
            61, 291, 39, 181, 0, 269
        )
        return mouthIndices.contains(index)
    }

    private fun isEyeLandmark(index: Int): Boolean {
        val eyeIndices = setOf(
            33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246,
            362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398
        )
        return eyeIndices.contains(index)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) {}

    private fun closeCamera() {
        if (::captureSession.isInitialized) {
            captureSession.close()
        }
        if (::cameraDevice.isInitialized) {
            cameraDevice.close()
        }
    }

    override fun onResume() {
        super.onResume()

        // 重新获取WakeLock
        try {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(10*60*1000L)
                Log.d("PowerManager", "WakeLock reacquisition")
            }
        } catch (e: Exception) {
            Log.e("PowerManager", "WakeLock reacquisition failed: ${e.message}")
        }

        // 重新上线Firebase
        if (::firebaseDatabase.isInitialized) {
            firebaseDatabase.goOnline()
            Log.d("Firebase", "Firebase is back online")
        }

        startBackgroundThread()
        if (textureView.isAvailable) {
            openCamera()
        } else {
            textureView.surfaceTextureListener = textureListener
        }
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()

        // Release audio resources
        try {
            warningMediaPlayer?.release()
            drowsinessMediaPlayer?.release()
            Log.d("Audio", "Audio resources released")
        } catch (e: Exception) {
            Log.e("Audio", "Failed to release audio resources: ${e.message}")
        }

        // Release WakeLock
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                    Log.d("PowerManager", "WakeLock released")
                }
            }
        } catch (e: Exception) {
            Log.e("PowerManager", "WakeLock release failed: ${e.message}")
        }

        if (::faceLandmarker.isInitialized) {
            faceLandmarker.close()
        }

        try {
            bluetoothSocket?.close()
        } catch (e: IOException) {
            Log.e("Bluetooth", "Failed to close Bluetooth connection: ${e.message}")
        }

        scope.cancel()
    }
}
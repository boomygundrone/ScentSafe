package com.scentsafe.android_facial_landmark

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.SurfaceTexture
import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelUuid
import android.os.PowerManager
import android.util.Log
import android.util.Size
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Runnable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.pow
import kotlin.math.sqrt

data class Point2D(val x: Float, val y: Float)

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    // UI组件
    private lateinit var surfaceView: SurfaceView
    private lateinit var textureView: TextureView
    private lateinit var statusTextView: TextView
    private lateinit var detailsTextView: TextView
    private lateinit var heartRateButton: Button
    private lateinit var settingsButton: Button

    // 音效相关
    private var warningMediaPlayer: MediaPlayer? = null
    private var drowsinessMediaPlayer: MediaPlayer? = null
    private lateinit var sharedPreferences: SharedPreferences
    private var soundEnabled = true
    private var selectedWarningSound = "bell"
    private var selectedDrowsinessSound = "alarm"
    private var lastWarningPlayTime = 0L
    private var lastDrowsinessPlayTime = 0L
    private val SOUND_COOLDOWN = 3000L

    // 相机和MediaPipe
    private lateinit var faceLandmarker: FaceLandmarker
    private lateinit var cameraManager: CameraManager
    private lateinit var cameraDevice: CameraDevice
    private lateinit var captureSession: CameraCaptureSession
    private lateinit var backgroundThread: HandlerThread
    private lateinit var backgroundHandler: Handler

    // Firebase
    private lateinit var firebaseDatabase: FirebaseDatabase
    private lateinit var drowsinessRef: DatabaseReference
    private lateinit var heartRateRef: DatabaseReference
    private var firebaseConnected = false
    private var lastFirebaseUpdate = 0L
    private val FIREBASE_UPDATE_INTERVAL = 2000L
    private val FIREBASE_TIMEOUT_CHECK = 15000L
    private var lastFirebaseCheck = System.currentTimeMillis()
    private var firebaseInitialized = false

    // 电源管理
    private lateinit var powerManager: PowerManager
    private var wakeLock: PowerManager.WakeLock? = null

    // ========== BLE 相關變數 ==========
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothLeScanner: BluetoothLeScanner? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var bleCharacteristic: BluetoothGattCharacteristic? = null

    private var isBleConnected = false
    private var isScanning = false
    private val discoveredBleDevices = mutableListOf<BluetoothDevice>()
    private val bleDeviceNames = mutableListOf<String>()
    private var bleDevicesDialog: androidx.appcompat.app.AlertDialog? = null

    // ESP32 BLE UUIDs (必須與 ESP32 程式碼一致)
    private val SERVICE_UUID = UUID.fromString("4fafc201-1fb5-459e-8fcc-c5c9c331914b")
    private val CHARACTERISTIC_UUID = UUID.fromString("beb5483e-36e1-4688-b7f5-ea07361b26a8")

    private val scanHandler = Handler(Looper.getMainLooper())
    private val SCAN_PERIOD: Long = 10000 // 10 seconds

    // 心率监测相关
    private var sensorManager: SensorManager? = null
    private var heartRateSensor: Sensor? = null
    private var heartRateListener: SensorEventListener? = null
    private var currentHeartRate = 75
    private var lastHeartRateUpdate = 0L
    private val HEART_RATE_UPDATE_INTERVAL = 10000L
    private var heartRateMonitoringActive = false
    private var heartRateHandler: Handler? = null
    private var heartRateRunnable: Runnable? = null

    // 检测参数
    private val EAR_THRESH = 0.18
    private val MAR_THRESH = 0.65
    private val EYES_CLOSED_DURATION = 1500L
    private val YAWN_DURATION = 1000L
    private val YAWN_THRESH = 3
    private val BLINK_THRESH = 15
    private val RAPID_BLINK_THRESH = 8
    private val DROWSINESS_YAWN_THRESH = 5
    private val DROWSINESS_BLINK_THRESH = 25
    private val TIME_WINDOW = 60000L
    private val BLINK_TIME_WINDOW = 10000L
    private val RAPID_BLINK_WINDOW = 5000L

    // 状态变量
    private var currentState = "NORMAL"
    private var lastSentState: String? = null
    private var eyesClosedStartTime: Long? = null
    private var yawnStartTime: Long? = null
    private var yawnCount = 0
    private var blinkCount = 0
    private var rapidBlinkCount = 0
    private var resetTime = System.currentTimeMillis()
    private var blinkResetTime = System.currentTimeMillis()
    private var rapidBlinkResetTime = System.currentTimeMillis()

    private var wasEyesClosed = false
    private var wasYawning = false
    private var lastBlinkTime = 0L

    // 滑动窗口数据
    private val earHistory = mutableListOf<Double>()
    private val marHistory = mutableListOf<Double>()
    private val HISTORY_SIZE = 5

    // 检测敏感度设置
    private var baselineEAR = 0.0
    private var baselineMAR = 0.0
    private var isBaselineSet = false
    private var frameCount = 0
    private val BASELINE_FRAMES = 50

    private var currentEAR = 0.0
    private var currentMAR = 0.0
    private var currentEARThresh = EAR_THRESH
    private var currentMARThresh = MAR_THRESH

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val CAMERA_PERMISSION_CODE = 100
    private var frontCameraId: String? = null
    private var previewSize: Size? = null
    private var lastInferenceTimeMs = 0L
    private val INFERENCE_INTERVAL_MS = 50L
    private var timestampMs = 0L

    private var lastUIUpdateTime = 0L
    private val UI_UPDATE_INTERVAL = 200L

    private val requestBtPermissions =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val granted = grants.values.all { it }
            if (granted) {
                startBleScan()
            } else {
                Toast.makeText(this, "BLE permissions denied", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        initializeSharedPreferences()
        initializePowerManagement()
        initializeViews()
        initializeAudioSystem()
        initializeFirebase()
        initializeBle() // 改為 BLE 初始化
        checkPermissions()
        startFirebaseMonitoring()
    }

    // ========== BLE 初始化 ==========
    private fun initializeBle() {
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        if (bluetoothAdapter == null) {
            Toast.makeText(this, "This device does not support Bluetooth", Toast.LENGTH_LONG).show()
            Log.e("BLE", "Device does not support Bluetooth")
            return
        }

        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "This device does not support BLE", Toast.LENGTH_LONG).show()
            Log.e("BLE", "Device does not support BLE")
            return
        }

        bluetoothLeScanner = bluetoothAdapter?.bluetoothLeScanner
        Log.d("BLE", "BLE initialized successfully")
    }

    // ========== BLE 掃描回調 ==========
    private val bleScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult?) {
            result?.let { scanResult ->
                val device = scanResult.device

                // 檢查權限
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                    ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                    return
                }

                // 過濾：只顯示名稱包含 "ESP32" 或 "XIAO" 或 "ScentSafe" 的設備
                val deviceName = device.name ?: "Unknown"
                if (!deviceName.contains("ESP32", ignoreCase = true) &&
                    !deviceName.contains("XIAO", ignoreCase = true) &&
                    !deviceName.contains("ScentSafe", ignoreCase = true)) {
                    return
                }

                // 去重
                val exists = discoveredBleDevices.any { it.address == device.address }
                if (!exists) {
                    discoveredBleDevices.add(device)
                    val label = "$deviceName (${device.address})"
                    bleDeviceNames.add(label)

                    runOnUiThread {
                        (bleDevicesDialog?.listView?.adapter as? android.widget.BaseAdapter)?.notifyDataSetChanged()
                    }

                    Log.d("BLE", "Found device: $label")
                }
            }
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>?) {
            results?.forEach { result ->
                onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, result)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            Log.e("BLE", "Scan failed with error code: $errorCode")
            runOnUiThread {
                Toast.makeText(this@MainActivity, "BLE scan failed: $errorCode", Toast.LENGTH_SHORT).show()
            }
            isScanning = false
        }
    }

    // ========== 開始 BLE 掃描 ==========
    private fun startBleScan() {
        val adapter = bluetoothAdapter ?: return

        if (!adapter.isEnabled) {
            Toast.makeText(this, "Please enable Bluetooth", Toast.LENGTH_SHORT).show()
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBtIntent)
            return
        }

        // 檢查權限
        val perms = mutableListOf<String>()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.BLUETOOTH_SCAN)
            }
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                perms.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (perms.isNotEmpty()) {
            requestBtPermissions.launch(perms.toTypedArray())
            return
        }

        // 顯示設備選擇對話框
        showBleDeviceDialog()
    }

    // ========== 顯示 BLE 設備選擇對話框 ==========
    private fun showBleDeviceDialog() {
        discoveredBleDevices.clear()
        bleDeviceNames.clear()

        val listAdapter = object : android.widget.BaseAdapter() {
            override fun getCount() = bleDeviceNames.size
            override fun getItem(position: Int) = bleDeviceNames[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val tv = (convertView as? android.widget.TextView)
                    ?: android.widget.TextView(parent.context).apply {
                        setPadding(32, 28, 32, 28)
                        textSize = 16f
                    }
                tv.text = bleDeviceNames[position]
                return tv
            }
        }

        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Select ESP32 BLE Device")
            .setAdapter(listAdapter) { dlg, which ->
                val device = discoveredBleDevices.getOrNull(which)
                device?.let { connectToBleDevice(it) }
                stopBleScan()
                dlg.dismiss()
            }
            .setNegativeButton("Close") { dlg, _ ->
                stopBleScan()
                dlg.dismiss()
            }
            .setPositiveButton("Scan") { _, _ -> }

        bleDevicesDialog = builder.create()
        bleDevicesDialog?.setOnShowListener {
            bleDevicesDialog?.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)?.setOnClickListener {
                if (isScanning) {
                    stopBleScan()
                    it as Button
                    it.text = "Scan"
                } else {
                    startBleScanInternal(listAdapter)
                    it as Button
                    it.text = "Stop"
                }
            }
        }
        bleDevicesDialog?.show()

        // 自動開始掃描
        startBleScanInternal(listAdapter)
    }

    // ========== 內部掃描邏輯 ==========
    private fun startBleScanInternal(listAdapter: android.widget.BaseAdapter) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        if (isScanning) {
            stopBleScan()
        }

        discoveredBleDevices.clear()
        bleDeviceNames.clear()
        listAdapter.notifyDataSetChanged()

        // 設置掃描過濾器（可選）
        val scanFilters = listOf(
            ScanFilter.Builder()
                .setServiceUuid(ParcelUuid(SERVICE_UUID))
                .build()
        )

        val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        bluetoothLeScanner?.startScan(scanFilters, scanSettings, bleScanCallback)
        isScanning = true

        Toast.makeText(this, "Scanning for ESP32 devices...", Toast.LENGTH_SHORT).show()
        Log.d("BLE", "BLE scan started")

        // 10秒後自動停止掃描
        scanHandler.postDelayed({
            if (isScanning) {
                stopBleScan()
                runOnUiThread {
                    Toast.makeText(this, "Scan completed", Toast.LENGTH_SHORT).show()
                }
            }
        }, SCAN_PERIOD)
    }

    // ========== 停止 BLE 掃描 ==========
    private fun stopBleScan() {
        if (!isScanning) return

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        bluetoothLeScanner?.stopScan(bleScanCallback)
        isScanning = false
        scanHandler.removeCallbacksAndMessages(null)
        Log.d("BLE", "BLE scan stopped")
    }

    // ========== 連接到 BLE 設備 ==========
    private fun connectToBleDevice(device: BluetoothDevice) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        Toast.makeText(this, "Connecting to ${device.name}...", Toast.LENGTH_SHORT).show()
        Log.d("BLE", "Connecting to ${device.address}")

        bluetoothGatt?.close()
        bluetoothGatt = device.connectGatt(this, false, gattCallback)
    }

    // ========== GATT 回調 ==========
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
                return
            }

            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    Log.d("BLE", "Connected to GATT server")
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "BLE Connected", Toast.LENGTH_SHORT).show()
                        updateBleDotColor(true)
                    }
                    isBleConnected = true
                    gatt?.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    Log.d("BLE", "Disconnected from GATT server")
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "BLE Disconnected", Toast.LENGTH_SHORT).show()
                        updateBleDotColor(false)
                    }
                    isBleConnected = false
                    bleCharacteristic = null
                }
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d("BLE", "Services discovered")

                val service = gatt?.getService(SERVICE_UUID)
                if (service != null) {
                    bleCharacteristic = service.getCharacteristic(CHARACTERISTIC_UUID)
                    if (bleCharacteristic != null) {
                        Log.d("BLE", "Characteristic found, ready to send data")
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "BLE Ready", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Log.e("BLE", "Characteristic not found")
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "BLE Characteristic not found", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    Log.e("BLE", "Service not found")
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "BLE Service not found", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Log.e("BLE", "Service discovery failed: $status")
            }
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt?, characteristic: BluetoothGattCharacteristic?, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d("BLE", "Data sent successfully")
            } else {
                Log.e("BLE", "Data send failed: $status")
            }
        }
    }

    // ========== 發送數據到 BLE ==========
    private fun sendToBle(state: String) {
        if (!isBleConnected || bleCharacteristic == null || bluetoothGatt == null) {
            Log.w("BLE", "BLE not ready, cannot send data")
            return
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        scope.launch(Dispatchers.IO) {
            try {
                val data = state.toByteArray(Charsets.UTF_8)

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    val result = bluetoothGatt?.writeCharacteristic(
                        bleCharacteristic!!,
                        data,
                        BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                    )
                    if (result == BluetoothStatusCodes.SUCCESS) {
                        Log.d("BLE", "Sent state: $state")
                    } else {
                        Log.e("BLE", "Write failed with code: $result")
                    }
                } else {
                    @Suppress("DEPRECATION")
                    bleCharacteristic?.value = data
                    @Suppress("DEPRECATION")
                    val success = bluetoothGatt?.writeCharacteristic(bleCharacteristic!!) ?: false
                    if (success) {
                        Log.d("BLE", "Sent state: $state")
                    } else {
                        Log.e("BLE", "Write characteristic failed")
                    }
                }
            } catch (e: Exception) {
                Log.e("BLE", "Send error: ${e.message}")
            }
        }
    }

    // ========== 更新藍牙指示燈顏色 ==========
    private fun updateBleDotColor(connected: Boolean) {
        val btDot = findViewById<View>(R.id.btDot)
        btDot?.background?.mutate()?.setTint(
            if (connected) getColorCompat(R.color.success) else Color.parseColor("#66FFFFFF")
        )
    }

    // ========== 修改 initializeViews 中的藍牙按鈕 ==========
    private fun setStateChipColor(state: String) {
        val chip = findViewById<TextView>(R.id.statusTextView)
        val bg = chip.background?.mutate()
        val color = when (state) {
            "NORMAL" -> getColorCompat(R.color.success)
            "WARNING" -> getColorCompat(R.color.warning)
            "DROWSINESS" -> getColorCompat(R.color.danger)
            else -> getColorCompat(R.color.brandPrimary)
        }
        if (bg is android.graphics.drawable.GradientDrawable) {
            bg.setColor(color)
        } else {
            val d = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = 999f
                setColor(color)
            }
            chip.background = d
        }
    }

    private fun getColorCompat(resId: Int): Int =
        androidx.core.content.ContextCompat.getColor(this, resId)

    private fun initializeSharedPreferences() {
        sharedPreferences = getSharedPreferences("DrowsinessDetectionSettings", Context.MODE_PRIVATE)
        soundEnabled = sharedPreferences.getBoolean("sound_enabled", true)
        selectedWarningSound = sharedPreferences.getString("warning_sound", "bell") ?: "bell"
        selectedDrowsinessSound = sharedPreferences.getString("drowsiness_sound", "alarm") ?: "alarm"
    }

    private fun initializeAudioSystem() {
        try {
            loadSoundFiles()
            Log.d("Audio", "Audio system initialized successfully")
        } catch (e: Exception) {
            Log.e("Audio", "Failed to initialize audio system: ${e.message}")
        }
    }

    private fun loadSoundFiles() {
        try {
            warningMediaPlayer?.release()
            warningMediaPlayer = when (selectedWarningSound) {
                "bell" -> MediaPlayer.create(this, R.raw.warning_bell)
                "cash" -> MediaPlayer.create(this, R.raw.warning_cash)
                "cock" -> MediaPlayer.create(this, R.raw.warning_cock)
                else -> MediaPlayer.create(this, R.raw.warning_bell)
            }

            drowsinessMediaPlayer?.release()
            drowsinessMediaPlayer = when (selectedDrowsinessSound) {
                "alarm" -> MediaPlayer.create(this, R.raw.drowsiness_alarm)
                "yay" -> MediaPlayer.create(this, R.raw.drowsiness_yay)
                "urgent" -> MediaPlayer.create(this, R.raw.drowsiness_urgent)
                else -> MediaPlayer.create(this, R.raw.drowsiness_alarm)
            }

            Log.d("Audio", "Sound files loaded")
        } catch (e: Exception) {
            Log.e("Audio", "Failed to load sound files: ${e.message}")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 200 && resultCode == RESULT_OK) {
            initializeSharedPreferences()
            loadSoundFiles()
        }
    }

    private fun playWarningSound() {
        if (!soundEnabled) return
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastWarningPlayTime < SOUND_COOLDOWN) return
        try {
            warningMediaPlayer?.let { player ->
                if (!player.isPlaying) {
                    player.start()
                    lastWarningPlayTime = currentTime
                }
            }
        } catch (e: Exception) {
            Log.e("Audio", "Failed to play warning sound: ${e.message}")
        }
    }

    private fun playDrowsinessSound() {
        if (!soundEnabled) return
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastDrowsinessPlayTime < SOUND_COOLDOWN) return
        try {
            drowsinessMediaPlayer?.let { player ->
                if (!player.isPlaying) {
                    player.start()
                    lastDrowsinessPlayTime = currentTime
                }
            }
        } catch (e: Exception) {
            Log.e("Audio", "Failed to play drowsiness sound: ${e.message}")
        }
    }

    private fun initializePowerManagement() {
        try {
            powerManager = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "DrowsinessDetection:WakeLock"
            )
            wakeLock?.acquire(10*60*1000L)
            Log.d("PowerManager", "WakeLock acquired")
        } catch (e: Exception) {
            Log.e("PowerManager", "WakeLock acquisition failed: ${e.message}")
        }
    }

    private fun initializeViews() {
        surfaceView = findViewById(R.id.surfaceView)
        textureView = findViewById(R.id.textureView)
        statusTextView = findViewById(R.id.statusTextView)
        detailsTextView = findViewById(R.id.detailsTextView)
        heartRateButton = findViewById(R.id.heartRateButton)
        settingsButton = findViewById(R.id.settingsButton)

        // BLE 按鈕
        val bluetoothButton: Button = findViewById(R.id.bluetoothButton)
        bluetoothButton.setOnClickListener { startBleScan() }

        heartRateButton.setOnClickListener {
            val intent = Intent(this, HeartRateActivity::class.java)
            startActivity(intent)
        }

        settingsButton.setOnClickListener {
            val intent = Intent(this, SoundSettingsActivity::class.java)
            startActivityForResult(intent, 200)
        }

        surfaceView.holder.addCallback(this)
        surfaceView.setZOrderOnTop(true)
        surfaceView.holder.setFormat(PixelFormat.TRANSLUCENT)
        textureView.surfaceTextureListener = textureListener

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        updateUIImmediate()
        setStateChipColor(currentState)

        // 初始 BLE 指示燈顏色
        findViewById<View>(R.id.btDot).background.setTint(Color.parseColor("#66FFFFFF"))
    }

    private fun initializeHeartRateMonitoring() {
        try {
            Log.d("HeartRate", "Start background heart rate monitoring initialization")
            sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
            heartRateSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_HEART_RATE)

            updateHeartRateToFirebase(75, false)

            if (heartRateSensor != null) {
                Log.d("HeartRate", "Device supports heart rate sensor")
            } else {
                Log.w("HeartRate", "Device does not support heart rate sensor")
            }
        } catch (e: Exception) {
            Log.e("HeartRate", "Heart rate monitoring initialization failed: ${e.message}")
        }
    }

    private fun updateHeartRateToFirebase(bpm: Int, monitoring: Boolean) {
        scope.launch(Dispatchers.IO) {
            try {
                val heartRateData = mapOf(
                    "bpm" to bpm,
                    "timestamp" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date()),
                    "lastUpdate" to ServerValue.TIMESTAMP,
                    "isMonitoring" to monitoring,
                    "deviceSupportsHeartRate" to (heartRateSensor != null),
                    "source" to if (monitoring) "sensor" else "default"
                )

                heartRateRef.setValue(heartRateData)
                    .addOnSuccessListener {
                        Log.d("Firebase", "Heart rate data updated: $bpm BPM")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "Heart rate update failed: ${exception.message}")
                    }
            } catch (e: Exception) {
                Log.e("Firebase", "Heart rate update error: ${e.message}")
            }
        }
    }

    private fun initializeFirebase() {
        try {
            if (!firebaseInitialized) {
                firebaseDatabase = FirebaseDatabase.getInstance("https://scentsafe-17cfd-default-rtdb.asia-southeast1.firebasedatabase.app/")

                try {
                    firebaseDatabase.setPersistenceEnabled(true)
                    Log.d("Firebase", "Persistence Enabled")
                } catch (e: Exception) {
                    Log.w("Firebase", "Persistence already enabled: ${e.message}")
                }

                drowsinessRef = firebaseDatabase.getReference("drowsiness_status")
                heartRateRef = firebaseDatabase.getReference("heartRate_value")

                drowsinessRef.keepSynced(true)
                heartRateRef.keepSynced(true)

                firebaseInitialized = true
            }

            val connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected")
            connectedRef.addValueEventListener(object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    val wasConnected = firebaseConnected
                    firebaseConnected = snapshot.getValue(Boolean::class.java) ?: false
                    Log.d("Firebase", "Connection Status: $firebaseConnected")

                    if (wasConnected != firebaseConnected) {
                        runOnUiThread {
                            if (firebaseConnected) {
                                Toast.makeText(this@MainActivity, "Firebase Connected", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "Firebase Disconnected", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                    Log.e("Firebase", "Connection monitoring failed: ${error.message}")
                }
            })

            Log.d("Firebase", "Firebase initialized successfully")

        } catch (e: Exception) {
            Log.e("Firebase", "Firebase initialization failed: ${e.message}")
            runOnUiThread {
                Toast.makeText(this, "Firebase initialization failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startFirebaseMonitoring() {
        scope.launch {
            while (isActive) {
                delay(FIREBASE_TIMEOUT_CHECK)

                val currentTime = System.currentTimeMillis()
                if (currentTime - lastFirebaseUpdate > FIREBASE_TIMEOUT_CHECK * 2) {
                    Log.w("Firebase", "Firebase update timeout, reconnecting...")
                    reconnectFirebase()
                }

                sendFirebaseHeartbeat()
            }
        }
    }

    private fun reconnectFirebase() {
        scope.launch(Dispatchers.IO) {
            try {
                Log.d("Firebase", "Reconnecting Firebase...")

                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Reconnecting to Firebase...", Toast.LENGTH_SHORT).show()
                }

                firebaseDatabase.goOffline()
                delay(3000)
                firebaseDatabase.goOnline()

                Log.d("Firebase", "Firebase reconnected")

            } catch (e: Exception) {
                Log.e("Firebase", "Firebase reconnection failed: ${e.message}")
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Firebase reconnection failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun sendFirebaseHeartbeat() {
        scope.launch(Dispatchers.IO) {
            try {
                if (::firebaseDatabase.isInitialized) {
                    val heartbeatRef = firebaseDatabase.getReference("heartbeat")
                    heartbeatRef.setValue(ServerValue.TIMESTAMP)
                        .addOnSuccessListener {
                            Log.d("Firebase", "Heartbeat sent")
                        }
                        .addOnFailureListener { exception ->
                            Log.e("Firebase", "Heartbeat failed: ${exception.message}")
                        }
                }
            } catch (e: Exception) {
                Log.e("Firebase", "Heartbeat error: ${e.message}")
            }
        }
    }

    private fun checkPermissions() {
        val permissionsNeeded = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.CAMERA)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WAKE_LOCK) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.WAKE_LOCK)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.BODY_SENSORS)
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        }

        if (permissionsNeeded.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissionsNeeded.toTypedArray(), CAMERA_PERMISSION_CODE)
        } else {
            setupCamera()
            initializeHeartRateMonitoring()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                setupCamera()
                initializeHeartRateMonitoring()
            } else {
                Toast.makeText(this, "Permissions required", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val textureListener = object : TextureView.SurfaceTextureListener {
        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
            openCamera()
        }
        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean = true
        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastInferenceTimeMs >= INFERENCE_INTERVAL_MS) {
                lastInferenceTimeMs = currentTime
                processFrame()
            }
        }
    }

    private fun setupCamera() {
        findFrontCamera()
        initFaceLandmarker()
        startBackgroundThread()
    }

    private fun findFrontCamera() {
        try {
            for (cameraId in cameraManager.cameraIdList) {
                val characteristics = cameraManager.getCameraCharacteristics(cameraId)
                val facing = characteristics.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    frontCameraId = cameraId
                    val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                    val sizes = map?.getOutputSizes(SurfaceTexture::class.java)
                    previewSize = sizes?.find { it.width == 1280 && it.height == 720 }
                        ?: sizes?.find { it.width == 640 && it.height == 480 }
                                ?: sizes?.firstOrNull()
                    break
                }
            }
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun initFaceLandmarker() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("face_landmarker.task")
                .build()

            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.6f)
                .setMinFacePresenceConfidence(0.6f)
                .setMinTrackingConfidence(0.7f)
                .setResultListener { result: FaceLandmarkerResult, input: MPImage ->
                    runOnUiThread {
                        processDrowsinessDetection(result, input)
                        displayResults(result, input)
                    }
                }
                .setErrorListener { error ->
                    runOnUiThread {
                        Toast.makeText(this, "Face detection error: ${error.message}", Toast.LENGTH_SHORT).show()
                    }
                }
                .build()

            faceLandmarker = FaceLandmarker.createFromOptions(this, options)
            Toast.makeText(this, "Drowsiness detection ready", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to initialize face detection: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun processDrowsinessDetection(result: FaceLandmarkerResult, input: MPImage) {
        if (result.faceLandmarks().isEmpty()) {
            resetDetectionState()
            return
        }

        val landmarks = result.faceLandmarks()[0]
        frameCount++

        val ear = calculateEAR(landmarks)
        val mar = calculateMAR(landmarks)

        currentEAR = ear
        currentMAR = mar

        establishBaseline(ear, mar)
        addToHistory(ear, mar)
        val smoothEAR = getSmoothedEAR()
        val smoothMAR = getSmoothedMAR()

        val currentTime = System.currentTimeMillis()

        currentEARThresh = if (isBaselineSet) baselineEAR * 0.70 else EAR_THRESH
        currentMARThresh = if (isBaselineSet) baselineMAR * 1.4 else MAR_THRESH

        detectYawnSensitive(smoothMAR, currentMARThresh, currentTime)
        detectBlinkPatterns(smoothEAR, currentEARThresh, currentTime)

        resetCounters(currentTime)
        updateDrowsinessState(smoothEAR, smoothMAR, currentEARThresh, currentMARThresh)

        if (currentTime - lastUIUpdateTime >= UI_UPDATE_INTERVAL) {
            updateUIImmediate()
            lastUIUpdateTime = currentTime
        }

        if (currentState != lastSentState || currentTime - lastFirebaseUpdate >= FIREBASE_UPDATE_INTERVAL) {
            updateFirebaseWithRetry(smoothEAR, smoothMAR)
            sendToBle(currentState) // 改為 BLE 發送
            lastSentState = currentState
        }
    }

    private fun resetDetectionState() {
        wasEyesClosed = false
        wasYawning = false
        eyesClosedStartTime = null
        yawnStartTime = null
    }

    private fun establishBaseline(ear: Double, mar: Double) {
        if (!isBaselineSet && frameCount <= BASELINE_FRAMES) {
            baselineEAR = (baselineEAR * (frameCount - 1) + ear) / frameCount
            baselineMAR = (baselineMAR * (frameCount - 1) + mar) / frameCount

            if (frameCount == BASELINE_FRAMES) {
                isBaselineSet = true
                Log.d("Baseline", "Baseline established - EAR: $baselineEAR, MAR: $baselineMAR")
                runOnUiThread {
                    Toast.makeText(this, "Baseline calibration completed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun detectYawnSensitive(mar: Double, threshold: Double, currentTime: Long) {
        if (mar >= threshold) {
            if (!wasYawning) {
                yawnStartTime = currentTime
                wasYawning = true
                Log.d("Yawn", "Yawn started: MAR = $mar")
            }
        } else {
            if (wasYawning && yawnStartTime != null) {
                val yawnDuration = currentTime - yawnStartTime!!
                if (yawnDuration >= YAWN_DURATION) {
                    yawnCount++
                    Log.d("Yawn", "Yawn detected! Duration: ${yawnDuration}ms, count: $yawnCount")
                }
                wasYawning = false
                yawnStartTime = null
            }
        }
    }

    private fun detectBlinkPatterns(ear: Double, threshold: Double, currentTime: Long) {
        if (ear < threshold) {
            if (!wasEyesClosed) {
                wasEyesClosed = true
                eyesClosedStartTime = currentTime
            }
        } else {
            if (wasEyesClosed) {
                blinkCount++

                if (currentTime - lastBlinkTime < 400) {
                    rapidBlinkCount++
                    Log.d("RapidBlink", "Rapid blink detected: $rapidBlinkCount")
                }

                lastBlinkTime = currentTime
                wasEyesClosed = false
                eyesClosedStartTime = null

                Log.d("Blink", "Blink detected: Total $blinkCount, Rapid $rapidBlinkCount")
            }
        }

        eyesClosedStartTime?.let { startTime ->
            if (currentTime - startTime >= EYES_CLOSED_DURATION) {
                Log.d("LongBlink", "Eyes closed for long time: ${currentTime - startTime}ms")
                currentState = "DROWSINESS"
            }
        }
    }

    private fun addToHistory(ear: Double, mar: Double) {
        earHistory.add(ear)
        marHistory.add(mar)

        if (earHistory.size > HISTORY_SIZE) {
            earHistory.removeAt(0)
        }
        if (marHistory.size > HISTORY_SIZE) {
            marHistory.removeAt(0)
        }
    }

    private fun getSmoothedEAR(): Double {
        return if (earHistory.isNotEmpty()) {
            earHistory.average()
        } else 0.3
    }

    private fun getSmoothedMAR(): Double {
        return if (marHistory.isNotEmpty()) {
            marHistory.average()
        } else 0.3
    }

    private fun resetCounters(currentTime: Long) {
        if (currentTime - resetTime > TIME_WINDOW) {
            yawnCount = 0
            blinkCount = 0
            resetTime = currentTime
            Log.d("Reset", "Counters reset")
        }

        if (currentTime - blinkResetTime > BLINK_TIME_WINDOW) {
            blinkResetTime = currentTime
        }

        if (currentTime - rapidBlinkResetTime > RAPID_BLINK_WINDOW) {
            rapidBlinkCount = 0
            rapidBlinkResetTime = currentTime
        }
    }

    private fun updateDrowsinessState(ear: Double, mar: Double, earThresh: Double, marThresh: Double) {
        val previousState = currentState

        currentState = when {
            yawnCount >= DROWSINESS_YAWN_THRESH ||
                    blinkCount >= DROWSINESS_BLINK_THRESH ||
                    rapidBlinkCount >= (RAPID_BLINK_THRESH * 2) ||
                    wasYawning && (System.currentTimeMillis() - (yawnStartTime ?: 0)) > 2000 -> {
                "DROWSINESS"
            }

            yawnCount >= YAWN_THRESH ||
                    blinkCount >= BLINK_THRESH ||
                    rapidBlinkCount >= RAPID_BLINK_THRESH ||
                    wasYawning -> {
                "WARNING"
            }

            else -> "NORMAL"
        }

        if (currentState != previousState) {
            when (currentState) {
                "WARNING" -> playWarningSound()
                "DROWSINESS" -> playDrowsinessSound()
            }
        }
    }

    private fun updateUIImmediate() {
        setStateChipColor(currentState)

        // BLE 連接指示燈
        val btDot = findViewById<View>(R.id.btDot)
        btDot.background?.mutate()?.setTint(
            if (isBleConnected) getColorCompat(R.color.success) else Color.parseColor("#66FFFFFF")
        )

        runOnUiThread {
            try {
                statusTextView.text = "State: $currentState"
                statusTextView.setTextColor(when (currentState) {
                    "NORMAL" -> Color.GREEN
                    "WARNING" -> Color.YELLOW
                    "DROWSINESS" -> Color.RED
                    else -> Color.WHITE
                })

                val connectionStatus = if (firebaseConnected) "Connected" else "Disconnected"
                val lastUpdateStr = if (lastFirebaseUpdate > 0) {
                    val timeDiff = (System.currentTimeMillis() - lastFirebaseUpdate) / 1000
                    "${timeDiff}s ago"
                } else "Not updated"

                val detailText = if (isBaselineSet) {
                    """EAR: %.3f / %.3f (Baseline: %.3f)
MAR: %.3f / %.3f (Baseline: %.3f)
Firebase: $connectionStatus | Last: $lastUpdateStr
Blinks: $blinkCount | Rapid: $rapidBlinkCount
Yawns: $yawnCount | Status: ${if(wasYawning) "Yawning" else "Normal"}
Frames: $frameCount""".format(
                        currentEAR, currentEARThresh, baselineEAR,
                        currentMAR, currentMARThresh, baselineMAR
                    )
                } else {
                    """EAR: %.3f / %.3f (Calibrating...)
MAR: %.3f / %.3f (Calibrating...)
Firebase: $connectionStatus | Last: $lastUpdateStr
Blinks: $blinkCount | Rapid: $rapidBlinkCount
Yawns: $yawnCount | Status: ${if(wasYawning) "Yawning" else "Normal"}
Calibration: $frameCount/$BASELINE_FRAMES""".format(
                        currentEAR, currentEARThresh,
                        currentMAR, currentMARThresh
                    )
                }

                detailsTextView.text = detailText

            } catch (e: Exception) {
                Log.e("UI", "UI update error: ${e.message}")
            }
        }
    }

    private fun calculateEAR(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Double {
        try {
            val leftEyePoints = listOf(
                Point2D(landmarks[33].x(), landmarks[33].y()),
                Point2D(landmarks[160].x(), landmarks[160].y()),
                Point2D(landmarks[158].x(), landmarks[158].y()),
                Point2D(landmarks[133].x(), landmarks[133].y()),
                Point2D(landmarks[153].x(), landmarks[153].y()),
                Point2D(landmarks[144].x(), landmarks[144].y())
            )

            val rightEyePoints = listOf(
                Point2D(landmarks[362].x(), landmarks[362].y()),
                Point2D(landmarks[385].x(), landmarks[385].y()),
                Point2D(landmarks[387].x(), landmarks[387].y()),
                Point2D(landmarks[263].x(), landmarks[263].y()),
                Point2D(landmarks[373].x(), landmarks[373].y()),
                Point2D(landmarks[380].x(), landmarks[380].y())
            )

            val leftEAR = calculateEnhancedEAR(leftEyePoints)
            val rightEAR = calculateEnhancedEAR(rightEyePoints)

            return (leftEAR + rightEAR) / 2.0
        } catch (e: Exception) {
            Log.e("EAR", "EAR calculation error: ${e.message}")
            return 0.3
        }
    }

    private fun calculateEnhancedEAR(eyePoints: List<Point2D>): Double {
        val vertical1 = distance(eyePoints[1], eyePoints[5])
        val vertical2 = distance(eyePoints[2], eyePoints[4])
        val horizontal = distance(eyePoints[0], eyePoints[3])

        return if (horizontal > 0) {
            (vertical1 + vertical2) / (2.0 * horizontal)
        } else 0.0
    }

    private fun calculateMAR(landmarks: List<com.google.mediapipe.tasks.components.containers.NormalizedLandmark>): Double {
        try {
            val upperLip = Point2D(landmarks[13].x(), landmarks[13].y())
            val lowerLip = Point2D(landmarks[14].x(), landmarks[14].y())
            val leftCorner = Point2D(landmarks[61].x(), landmarks[61].y())
            val rightCorner = Point2D(landmarks[291].x(), landmarks[291].y())

            val upperLip2 = Point2D(landmarks[12].x(), landmarks[12].y())
            val lowerLip2 = Point2D(landmarks[15].x(), landmarks[15].y())

            val vertical1 = distance(upperLip, lowerLip)
            val vertical2 = distance(upperLip2, lowerLip2)
            val avgVertical = (vertical1 + vertical2) / 2.0

            val horizontal = distance(leftCorner, rightCorner)

            return if (horizontal > 0) avgVertical / horizontal else 0.0
        } catch (e: Exception) {
            Log.e("MAR", "MAR calculation error: ${e.message}")
            return 0.3
        }
    }

    private fun distance(p1: Point2D, p2: Point2D): Double {
        return sqrt((p1.x - p2.x).toDouble().pow(2) + (p1.y - p2.y).toDouble().pow(2))
    }

    private fun updateFirebaseWithRetry(ear: Double, mar: Double) {
        scope.launch(Dispatchers.IO) {
            try {
                val drowsinessData = mapOf(
                    "blinkCount" to blinkCount,
                    "eyeAspectRatio" to ear,
                    "mouthAspectRatio" to mar,
                    "state" to currentState,
                    "timestamp" to SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date()),
                    "yawnCount" to yawnCount,
                    "lastUpdate" to ServerValue.TIMESTAMP,
                    "frameCount" to frameCount,
                    "appVersion" to "1.0.0"
                )

                drowsinessRef.setValue(drowsinessData)
                    .addOnSuccessListener {
                        lastFirebaseUpdate = System.currentTimeMillis()
                        Log.d("Firebase", "Drowsiness data updated")
                    }
                    .addOnFailureListener { exception ->
                        Log.e("Firebase", "Update failed: ${exception.message}")
                        retryFirebaseUpdate(drowsinessData, 1, 3)
                    }

                updateHeartRateToFirebase(currentHeartRate, heartRateMonitoringActive)

            } catch (e: Exception) {
                Log.e("Firebase", "Firebase operation error: ${e.message}")
            }
        }
    }

    private fun retryFirebaseUpdate(data: Map<String, Any>, currentRetry: Int, maxRetries: Int) {
        if (currentRetry > maxRetries) {
            Log.e("Firebase", "Firebase update failed after $maxRetries retries")
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Firebase connection failed, reconnecting...", Toast.LENGTH_SHORT).show()
            }
            reconnectFirebase()
            return
        }

        Handler(Looper.getMainLooper()).postDelayed({
            scope.launch(Dispatchers.IO) {
                try {
                    drowsinessRef.setValue(data)
                        .addOnSuccessListener {
                            lastFirebaseUpdate = System.currentTimeMillis()
                            Log.d("Firebase", "Retry $currentRetry successful")
                        }
                        .addOnFailureListener { exception ->
                            Log.e("Firebase", "Retry $currentRetry failed: ${exception.message}")
                            retryFirebaseUpdate(data, currentRetry + 1, maxRetries)
                        }
                } catch (e: Exception) {
                    Log.e("Firebase", "Retry error: ${e.message}")
                    retryFirebaseUpdate(data, currentRetry + 1, maxRetries)
                }
            }
        }, (1000 * currentRetry).toLong())
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread.looper)
    }

    private fun stopBackgroundThread() {
        if (::backgroundThread.isInitialized) {
            backgroundThread.quitSafely()
            try {
                backgroundThread.join()
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        }
    }

    private fun openCamera() {
        frontCameraId?.let { cameraId ->
            try {
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    return
                }

                cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                    override fun onOpened(camera: CameraDevice) {
                        cameraDevice = camera
                        createCameraPreviewSession()
                    }

                    override fun onDisconnected(camera: CameraDevice) {
                        camera.close()
                    }

                    override fun onError(camera: CameraDevice, error: Int) {
                        camera.close()
                        Toast.makeText(this@MainActivity, "Camera startup failed", Toast.LENGTH_SHORT).show()
                    }
                }, backgroundHandler)
            } catch (e: CameraAccessException) {
                e.printStackTrace()
            }
        }
    }

    private fun createCameraPreviewSession() {
        try {
            val texture = textureView.surfaceTexture
            previewSize?.let { size ->
                texture?.setDefaultBufferSize(size.width, size.height)
            }

            val surface = Surface(texture)
            val previewRequestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewRequestBuilder.addTarget(surface)

            cameraDevice.createCaptureSession(
                listOf(surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        captureSession = session
                        updatePreview(previewRequestBuilder)
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Toast.makeText(this@MainActivity, "Camera configuration failed", Toast.LENGTH_SHORT).show()
                    }
                },
                null
            )
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun updatePreview(previewRequestBuilder: CaptureRequest.Builder) {
        try {
            previewRequestBuilder.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
            previewRequestBuilder.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            previewRequestBuilder.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            captureSession.setRepeatingRequest(previewRequestBuilder.build(), null, backgroundHandler)
        } catch (e: CameraAccessException) {
            e.printStackTrace()
        }
    }

    private fun processFrame() {
        if (!::faceLandmarker.isInitialized) return

        scope.launch(Dispatchers.IO) {
            try {
                val bitmap = textureView.getBitmap() ?: return@launch

                val argbBitmap = if (bitmap.config == Bitmap.Config.ARGB_8888) {
                    bitmap
                } else {
                    bitmap.copy(Bitmap.Config.ARGB_8888, false)
                }

                val mpImage = BitmapImageBuilder(argbBitmap).build()
                timestampMs = System.currentTimeMillis()
                faceLandmarker.detectAsync(mpImage, timestampMs)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun displayResults(result: FaceLandmarkerResult, input: MPImage) {
        try {
            val width = textureView.width
            val height = textureView.height

            if (width <= 0 || height <= 0) return

            val statusPaint = Paint().apply {
                textSize = 48f
                isAntiAlias = true
                color = when (currentState) {
                    "NORMAL" -> Color.GREEN
                    "WARNING" -> Color.YELLOW
                    "DROWSINESS" -> Color.RED
                    else -> Color.WHITE
                }
                style = Paint.Style.FILL
                setShadowLayer(4f, 2f, 2f, Color.BLACK)
            }

            val landmarkPaint = Paint().apply {
                color = Color.argb(255, 0, 255, 127)
                style = Paint.Style.FILL
                strokeWidth = 2f
                isAntiAlias = true
            }

            val eyeLandmarkPaint = Paint().apply {
                color = if (wasEyesClosed) Color.RED else Color.CYAN
                style = Paint.Style.FILL
                strokeWidth = 4f
                isAntiAlias = true
            }

            val mouthLandmarkPaint = Paint().apply {
                color = if (wasYawning) Color.RED else Color.YELLOW
                style = Paint.Style.FILL
                strokeWidth = 4f
                isAntiAlias = true
            }

            val holder: SurfaceHolder = surfaceView.holder
            val canvas = holder.lockCanvas() ?: return

            canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

            val detailPaint = Paint().apply {
                textSize = 28f
                color = Color.WHITE
                setShadowLayer(2f, 1f, 1f, Color.BLACK)
            }

            canvas.drawText("Blinks: $blinkCount | Yawns: $yawnCount | Firebase: ${if(firebaseConnected) "✓" else "✗"}", 50f, 150f, detailPaint)

            result.faceLandmarks().forEach { landmarks ->
                landmarks.forEachIndexed { landmarkIndex, landmark ->
                    val x = landmark.x() * width
                    val y = landmark.y() * height

                    val (paint, radius) = when {
                        isMouthLandmark(landmarkIndex) -> Pair(mouthLandmarkPaint, 5f)
                        isEyeLandmark(landmarkIndex) -> Pair(eyeLandmarkPaint, 5f)
                        else -> Pair(landmarkPaint, 2f)
                    }

                    canvas.drawCircle(x, y, radius, paint)
                }
            }

            holder.unlockCanvasAndPost(canvas)

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun isMouthLandmark(index: Int): Boolean {
        val mouthIndices = setOf(
            0, 11, 12, 13, 14, 15, 16, 17, 18, 200, 199, 175,
            61, 84, 17, 314, 405, 320, 307, 375, 321, 308, 324, 318, 402, 317,
            14, 87, 178, 88, 95, 78, 191, 80, 81, 82, 13, 312, 311, 310, 415,
            61, 291, 39, 181, 0, 269
        )
        return mouthIndices.contains(index)
    }

    private fun isEyeLandmark(index: Int): Boolean {
        val eyeIndices = setOf(
            33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246,
            362, 382, 381, 380, 374, 373, 390, 249, 263, 466, 388, 387, 386, 385, 384, 398
        )
        return eyeIndices.contains(index)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {}
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}
    override fun surfaceDestroyed(holder: SurfaceHolder) {}

    private fun closeCamera() {
        if (::captureSession.isInitialized) {
            captureSession.close()
        }
        if (::cameraDevice.isInitialized) {
            cameraDevice.close()
        }
    }

    override fun onResume() {
        super.onResume()

        try {
            if (wakeLock?.isHeld != true) {
                wakeLock?.acquire(10*60*1000L)
                Log.d("PowerManager", "WakeLock reacquired")
            }
        } catch (e: Exception) {
            Log.e("PowerManager", "WakeLock reacquisition failed: ${e.message}")
        }

        if (::firebaseDatabase.isInitialized) {
            firebaseDatabase.goOnline()
            Log.d("Firebase", "Firebase back online")
        }

        startBackgroundThread()
        if (textureView.isAvailable) {
            openCamera()
        } else {
            textureView.surfaceTextureListener = textureListener
        }
    }

    override fun onPause() {
        closeCamera()
        stopBackgroundThread()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()

        // Release audio resources
        try {
            warningMediaPlayer?.release()
            drowsinessMediaPlayer?.release()
            Log.d("Audio", "Audio resources released")
        } catch (e: Exception) {
            Log.e("Audio", "Failed to release audio resources: ${e.message}")
        }

        // Release WakeLock
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                    Log.d("PowerManager", "WakeLock released")
                }
            }
        } catch (e: Exception) {
            Log.e("PowerManager", "WakeLock release failed: ${e.message}")
        }

        // Close BLE connection
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
                // Permission not granted, but still try to close
            }
            bluetoothGatt?.close()
            bluetoothGatt = null
            isBleConnected = false
            Log.d("BLE", "BLE connection closed")
        } catch (e: Exception) {
            Log.e("BLE", "Failed to close BLE connection: ${e.message}")
        }

        if (::faceLandmarker.isInitialized) {
            faceLandmarker.close()
        }

        scope.cancel()
    }
}

